package org.example.users;

import lombok.Getter;
import lombok.Setter;

public class User {

    @Getter @Setter private String login;
    @Getter @Setter private String password;
    @Getter @Setter private int money;


    public User(String login, String password) {
        this.login = login;
        this.password = password;
    }
}
