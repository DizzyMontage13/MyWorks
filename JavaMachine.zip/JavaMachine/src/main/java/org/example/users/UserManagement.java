package org.example.users;

import java.util.HashMap;

public class UserManagement {

    private static final HashMap<String, User> users = new HashMap<>();


    public static void createUser(String login, String password) {
        User user = new User(login, password);

        users.put(login, user);
    }

    public static User getUser(String login) {

        for(String log : users.keySet()) {
            if(log.equals(login)) {
                return users.get(login);
            }
        }
        return null;
    }


    public HashMap<String, User> getUsers() {
        return users;
    }
}
