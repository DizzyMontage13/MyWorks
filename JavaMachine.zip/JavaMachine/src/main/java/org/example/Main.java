package org.example;

import org.example.panels.MainMenu;
import org.example.panels.RegisterMenu;
import org.example.users.User;
import org.example.users.UserManagement;

public class Main {
    private MainMenu mainMenu;
    private RegisterMenu registerMenu;
    private MainJFrame mainJFrame;

    public static void main(String[] args) {
        Main main = new Main();
        main.runApplication();

    }

    public void runApplication() {
        this.mainMenu = new MainMenu(this);
        this.registerMenu = new RegisterMenu(this);
        this.mainJFrame = new MainJFrame(this);

        UserManagement.createUser("Test", "Test");
    }

    public RegisterMenu getRegisterMenu() {
        return this.registerMenu;
    }

    public MainMenu getMainMenu() {
        return this.mainMenu;
    }

    public MainJFrame getMainJFrame() { return this.mainJFrame; }
}