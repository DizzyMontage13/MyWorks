package org.example.panels;

import lombok.Getter;
import lombok.Setter;
import org.example.Main;
import org.example.MainJFrame;
import org.example.users.User;
import org.example.users.UserManagement;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu extends JPanel{
    @Getter @Setter private JPanel panel1;
    @Getter @Setter private JLabel Title;
    @Getter @Setter private JButton LogIn;
    @Getter @Setter private JTextField Login;
    @Getter @Setter private JTextField Password;
    private JLabel reason;
    private JButton createAccountButton;

    private final Main main;


    public MainMenu (Main main) {
       this.main = main;
       actionListener();
       createAccount();
    }


    public void createAccount() {
        createAccountButton.addActionListener(e -> {
            main.getMainJFrame().setContentPane(main.getRegisterMenu().getRegisterPanel());
            main.getMainJFrame().invalidate();
            main.getMainJFrame().validate();
//            main.getMainJFrame().setContentPane(main.getMainMenu());
        });
    }


    public void actionListener() {
       LogIn.addActionListener(e -> {

           String login = Login.getText();
           String password = Password.getText();

          if(login.isEmpty() || password.isEmpty()) {
             reason.setText("Type something in brackets");
             return;
          }

          User user = UserManagement.getUser(login);

          if(user == null) {
             reason.setText("User not found");
             return;
          }

          if(!(user.getLogin().equals(login)) || !(user.getPassword().equals(password))) {
             reason.setText("Incorrect password or login");
             return;
          }

          reason.setText("Logged In");
       });
    }
}
