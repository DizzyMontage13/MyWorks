package org.example.panels;

import lombok.Getter;
import lombok.Setter;
import org.example.Main;
import org.example.users.User;
import org.example.users.UserManagement;

import javax.swing.*;

public class RegisterMenu extends JPanel{
    @Getter @Setter private JPanel registerPanel;
    @Getter @Setter private JButton register;
    @Getter @Setter private JTextField Login;
    @Getter @Setter private JTextField Password;
    @Getter @Setter private JLabel Title;
    @Getter @Setter private JLabel reason;
    @Getter @Setter private JRadioButton acceptedAllPoliticsRadioButton;
    private final Main main;

    public RegisterMenu(Main main) {
        this.main = main;
        onRegister();
    }


    public void onRegister() {
        register.addActionListener(e -> {

            String login = Login.getText();
            String password = Password.getText();

            if(login.isEmpty() || password.isEmpty()) {
                reason.setText("Type something in brackets");
                return;
            }

            User user = UserManagement.getUser(login);

            if(user != null) {
                reason.setText("Actually user exists.");
                return;
            }

            if(!acceptedAllPoliticsRadioButton.isSelected()) {
                reason.setText("Accept politics");
                return;
            }
            reason.setText("Account created");
            UserManagement.createUser(login, password);
            main.getMainJFrame().setContentPane(main.getMainMenu().getPanel1());
            main.getMainJFrame().invalidate();
            main.getMainJFrame().validate();
        });
    }
}
