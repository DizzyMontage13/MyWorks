package org.example;


import javax.swing.*;

public class MainJFrame extends JFrame {

    private final Main main;
    public MainJFrame(Main main) {
        this.main = main;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 1000);
        setResizable(false);
        setVisible(true);
        setTitle("DBank - Your bank, us money!");
        setContentPane(main.getMainMenu().getPanel1());
    }
}
