package me.dizzymontage;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main implements ActionListener {

    JButton[] button = new JButton[9];
    boolean player1turn = true;
    JButton rbutton = new JButton("Reset");

    JLabel label = new JLabel();

    JLabel whoTurn = new JLabel();

    String letter;

    Main() {
        CreateGui();
    }


    public static void main(String[] args) {
        new Main();
    }

    public void CreateGui() {

        JPanel panel = new JPanel();

        panel.setBounds(0, 100, 600, 600);
        panel.setBackground(Color.darkGray);
        panel.setLayout(new GridLayout(3,3));

        JFrame Frame = new JFrame("TicTacToe");
        Frame.setSize(610, 700);
        Frame.setLayout(null);

        JPanel panel1 = new JPanel();


        panel1.setBounds(0,0, 600, 100);
        panel1.setBackground(Color.darkGray);

        Frame.setResizable(false);
        Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



        rbutton.setFocusable(true);
        rbutton.addActionListener(this);
        panel1.add(rbutton);

        whoTurn.setForeground(Color.RED);
        whoTurn.setFont(new Font("Kids", Font.ITALIC, 20));


        panel1.add(whoTurn);

        label.setForeground(Color.white);
        label.setFont(new Font("Ink Free",Font.BOLD, 40));
        label.setHorizontalAlignment(JLabel.CENTER);



        panel1.setLayout(new GridLayout(2, 2));
        panel1.add(label);

        for(int i = 0; i < 9; i++) {
            button[i] = new JButton();
            panel.add(button[i]);
            button[i].setFocusable(false);
            button[i].setBackground(Color.white);
            button[i].addActionListener(this);
        }


        whoTurn.setText("O TURN");

        Frame.setVisible(true);
        Frame.add(panel);
        Frame.add(panel1);
    }

    public void actionPerformed(ActionEvent event) {

        if(event.getSource() == rbutton) {
            for(int i = 0; i<9; i++) {
                button[i].setText("");
                button[i].setBackground(Color.WHITE);
                player1turn = true;
                button[i].setEnabled(true);
            }
            label.setText("");
            whoTurn.setText("O TURN");
        }

        for(int i = 0; i < 9; i++) {
            if(event.getSource() == button[i]) {
                if(button[i].getText() == "" || button[i].getText().isEmpty()) {
                    if(player1turn) {
                        button[i].setText("O");
                        button[i].setBackground(Color.RED);
                        player1turn = false;
                        CheckWin();
                        whoTurn.setText("X TURN");
                    } else {
                        button[i].setText("X");
                        button[i].setBackground(Color.BLUE);
                        player1turn = true;
                        button[i].setEnabled(true);
                        CheckWin();
                        whoTurn.setText("O TURN");
                    }
                }
            }
        }
    }

    public void CheckWin() {
        if (button[0].getText().equals("X") &&
                button[3].getText().equals("X") &&
                button[6].getText().equals("X"))
        {
            WhoWin("X");

        }
        if (button[1].getText().equals("X") &&
                button[4].getText().equals("X") &&
                button[7].getText().equals("X"))
        {
            WhoWin("X");
        }
        if (button[2].getText().equals("X") &&
                button[5].getText().equals("X") &&
                button[8].getText().equals("X"))
        {
            WhoWin("X");
        }
        if (button[0].getText().equals("X") &&
                button[1].getText().equals("X") &&
                button[2].getText().equals("X"))
        {
            WhoWin("X");
        }
        if (button[3].getText().equals("X") &&
                button[4].getText().equals("X") &&
                button[5].getText().equals("X"))
        {
            WhoWin("X");
        }
        if (button[6].getText().equals("X") &&
                button[7].getText().equals("X") &&
                button[8].getText().equals("X"))
        {
            WhoWin("X");
        }
        if (button[0].getText().equals("X") &&
                button[4].getText().equals("X") &&
                button[8].getText().equals("X"))
        {
            WhoWin("X");
        }
        if (button[2].getText().equals("X") &&
                button[4].getText().equals("X") &&
                button[6].getText().equals("X"))
        {
            WhoWin("X");
        }





        if (button[0].getText().equals("O") &&
                button[3].getText().equals("O") &&
                button[6].getText().equals("O"))
        {
            WhoWin("O");
        }
        if (button[1].getText().equals("O") &&
                button[4].getText().equals("O") &&
                button[7].getText().equals("O"))
        {
            WhoWin("O");
        }
        if (button[2].getText().equals("O") &&
                button[5].getText().equals("O") &&
                button[8].getText().equals("O"))
        {
            WhoWin("O");
        }
        if (button[0].getText().equals("O") &&
                button[1].getText().equals("O") &&
                button[2].getText().equals("O"))
        {
            WhoWin("O");
        }
        if (button[3].getText().equals("O") &&
                button[4].getText().equals("O") &&
                button[5].getText().equals("O"))
        {
            WhoWin("O");
        }
        if (button[6].getText().equals("O") &&
                button[7].getText().equals("O") &&
                button[8].getText().equals("O"))
        {
            WhoWin("O");
        }
        if (button[0].getText().equals("O") &&
                button[4].getText().equals("O") &&
                button[8].getText().equals("O"))
        {
            WhoWin("O");
        }
        if (button[2].getText().equals("O") &&
                button[4].getText().equals("O") &&
                button[6].getText().equals("O"))
        {
            WhoWin("O");
        }
    }

    public void WhoWin(String letter) {
        if(letter.equals("X")) {
            label.setText("X WON");
            whoTurn.setText(" ");

            for (int i = 0;  i < 9; i++) {
                button[i].setEnabled(false);
            }
        } else if(letter.equals("O")) {
            label.setText(" " + "\r\n \r\n \r\n" + "O WON");
            whoTurn.setText(" ");

            for (int i = 0;  i < 9; i++) {
                button[i].setEnabled(false);
            }
        }



    }
}
