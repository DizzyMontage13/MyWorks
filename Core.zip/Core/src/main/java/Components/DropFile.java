package Components;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.logging.Level;

import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class DropFile {
    private static final Main plugin = Main.getMain();

    private static FileConfiguration dropConfig = null;

    private static File dropConfigFile = null;

    public static void reloadConfig() {
        if (dropConfigFile == null)
            dropConfigFile = new File(plugin.getDataFolder(), "drops.yml");
        dropConfig = YamlConfiguration.loadConfiguration(dropConfigFile);
        InputStream defConfigStream = plugin.getResource("drops.yml");
        if (defConfigStream != null) {
            YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(defConfigStream));
            dropConfig.setDefaults((Configuration)defConfig);
        }
    }

    public static FileConfiguration getConfig() {
        if (dropConfig == null)
            reloadConfig();
        return dropConfig;
    }

    public static void saveConfig() {
        if (dropConfig == null || dropConfigFile == null)
            return;
        try {
            getConfig().save(dropConfigFile);
        } catch (IOException ex) {
            Bukkit.getLogger().log(Level.SEVERE, "Could not save config to " + dropConfigFile, ex);
        }
    }

    public static void saveDefaultConfig() {
        if (dropConfigFile == null)
            dropConfigFile = new File(plugin.getDataFolder(), "drops.yml");
        if (!dropConfigFile.exists())
            plugin.saveResource("drops.yml", false);
    }
}
