package Components;

import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;

import java.util.List;
import java.util.Objects;

public class PlayerData extends DataManager {

    public PlayerData(Main main) {
        super(main, "Stoniarki.yml");
    }


    public Location getLocationFromString(String string) {

        String[] parts = Objects.requireNonNull(config.getString("Stoniarki")).split(":");

        return new Location(Bukkit.getServer().getWorld(parts[3]), Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
    }

    public void saveLocation(String string) {
        List<String> list = config.getStringList("Stoniarka");
        list.add(string);
        config.set("Stoniarka", list);
        save();
    }

    public boolean GetLocation(String string) {
        List<String> list = config.getStringList("Stoniarka");

        return !list.contains(string);
    }

    public void removeLocation(String string) {
        List<String> list = config.getStringList("Stoniarka");

        list.remove(string);
        config.set("Stoniarka", list);
        save();
    }
}
