package Components;

import Utils.mySQL;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

public class User {

    private String uuid;
    private long kit_gracz;
    private long kit_vip;
    private long kit_mieso;
    private @Getter @Setter long kit_svip;

    Utils.mySQL mySQL = new mySQL();

    public User(String uuid) {
        this.uuid = uuid;
        this.kit_gracz = 0L;
        this.kit_vip = 0L;
        this.kit_mieso = 0L;
    }

    public User(String uuid, long gracz, long vip, long mieso) {
        this.uuid = uuid;
        this.kit_gracz = gracz;
        this.kit_vip = vip;
        this.kit_mieso = mieso;
    }


    public User(UUID uuid) {
        this.uuid = uuid.toString();
        this.kit_gracz = 0L;
        this.kit_vip = 0L;
        this.kit_mieso = 0L;
    }

    public User(ResultSet resultSet) throws SQLException {
        this.uuid = resultSet.getString("UUID");
        this.kit_gracz = resultSet.getLong("KIT_GRACZ");
        this.kit_vip = resultSet.getLong("KIT_VIP");
        this.kit_mieso = resultSet.getLong("KIT_MIESO");
    }

    public void insertSQL() {
        mySQL.update("INSERT INTO kits (UUID, KIT_GRACZ, KIT_VIP, KIT_MIESO) VALUES ('" + getUuid() + "' ,'" + getKit_gracz() + "','" + getKit_vip() + "','" + getKit_mieso() + "');");
    }

    //preparedStatement = connection.prepareStatement("CREATE TABLE IF NOT EXISTS kits (UUID VARCHAR(255), KIT_GRACZ BIGINT, KIT_VIP BIGINT, KIT_MIESO BIGINT;");

    public void UpdateSQL() {
        mySQL.update("UPDATE kits SET KIT_GRACZ ='" + getKit_gracz() + "', KIT_VIP = '" + getKit_vip() + "', KIT_MIESO = '" + getKit_mieso() + "'  WHERE UUID = '" + getUuid() + "';");
    }

    public String getUuid() {
        return this.uuid;
    }

    public long getKit_mieso() { return kit_mieso; }

    public long getKit_vip() { return kit_vip; }

    public long getKit_gracz() { return this.kit_gracz; }

    public Player getPlayer() {
        return Bukkit.getPlayer(uuid);
    }

    public void setKit_gracz(long kit_gracz) { this.kit_gracz = kit_gracz; }

    public void setkit_vip (long kit_vip) { this.kit_vip = kit_vip; }

    public void setKit_mieso(long kit_mieso) { this.kit_mieso = kit_mieso; }

    public boolean ifkit_gracz_exists() {

        if(getKit_gracz() == 0L) {
            return false;
        }

        return true;
    }

    public boolean ifkit_vip_exists() {
        if (getKit_vip() == 0L) {
            return false;
        }

        return true;
    }
}
