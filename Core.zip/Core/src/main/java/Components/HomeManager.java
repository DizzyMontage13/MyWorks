package Components;

import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;

import java.util.HashSet;
import java.util.Objects;
import java.util.UUID;

public class HomeManager {


    private static final HashSet<Home> Homes = new HashSet<>();

    public void setHome(UUID uuid) {
        for(String string : HomeFile.getConfig().getConfigurationSection("Homes").getKeys(false)) {
            Home home = new Home(uuid);
            Homes.add(home);
        }
    }

    public boolean HomeExist(UUID uuid) {
        Home home = new Home(uuid);
        return home.getNickname().equals(uuid);
    }

    public void AddPlayer(UUID uuid, double x, double y, double z) {
        Home home = new Home(uuid);
        home.setAdX(x);
        home.setAdY(y);
        home.setAdZ(z);
    }

    public Location getHome(UUID uuid) {
        Home home = new Home(uuid);

        return new Location(Bukkit.getServer().getWorld(uuid), home.getAdX(), home.getAdY(), home.getAdZ());
    }

    public void setHomes(UUID uuid, Location location) {

        double x = location.getX();
        double y = location.getY();
        double z = location.getZ();
        World world = location.getWorld();

        AddPlayer(uuid, x, y, z);
    }
}
