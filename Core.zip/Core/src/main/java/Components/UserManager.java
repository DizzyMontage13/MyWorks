package Components;

import Utils.mySQL;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class UserManager {


    private final List<User> users = new ArrayList<>();

    public User getUser(String UUID) {
        for(User u : users) {

            if(u.getUuid().toString().equalsIgnoreCase(UUID))
                return u;

        }
        return null;
    }

    public void createUser(UUID uuid) {

        User u = new User(uuid);
        users.add(u);

    }

    public boolean ifUserExist(UUID uuid) {

        String string = uuid.toString();

        return users.contains(string);
    }

    public void creatorUser(String uuid) {

        User u = new User(uuid);
        users.add(u);

    }

    public void deleteUser(User user) {
        users.remove(user.toString());

        mySQL mySQL = new mySQL();
        mySQL.update("DELETE FROM KITS WHERE UUID='" + user.getUuid() + "'");
    }


//    public static void loadUsers() {
//        try {
//            MySQL mySQL = new MySQL();
//            ResultSet resultSet = mySQL.updaters("SELECT * FROM KITS");
//
//
//            while (resultSet.next()) {
//                User user = new User(resultSet);
//                users.put(user.getUuid(), user);
//            }
//            resultSet.close();
//            System.out.println("[DIZZYCORE]      Zaladowano " + users.size());
//        } catch (SQLException e) {
//            e.printStackTrace();
//            Bukkit.broadcastMessage("[DIZZYCORE]      NIE MOZNA ZALADOWAC " + e.getMessage());
//        }
//    }

    public List<User> getUsers() {
        return this.users;
    }
}

