package Components.Recipes;

import Utils.GeneratorStoneBlock;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;

public class GeneratorStoneBlockRecipe {


    static Main plugin;

    public GeneratorStoneBlockRecipe(Main main) {
        plugin = main;
    }

    public static void getRecipe() {

        ItemStack item = GeneratorStoneBlock.getGeneratorStoneBlock(1);

        NamespacedKey key = new NamespacedKey(Main.getMain(), "Stoniarka");

        ShapedRecipe recipe = new ShapedRecipe(key, item);

        recipe.shape(
                "SSS",
                "SES",
                "SSS"
        );

        recipe.setIngredient('S', Material.STONE);
        recipe.setIngredient('E', Material.EMERALD);

        plugin.getServer().addRecipe(recipe);
    }

}
