package Components.Recipes;

import Utils.FarmerBlock;
import Utils.GeneratorStoneBlock;
import com.Challangerson.Main;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.material.MaterialData;

public class FarmersRecipe {


    static Main plugin;

    public FarmersRecipe(Main main) {
        plugin = main;
    }

    public static void getBoyFarmerRecipe() {

        ItemStack item = FarmerBlock.getBoyFarmer(1);

        NamespacedKey key = new NamespacedKey(Main.getMain(), "BoyFarmer");

        ShapedRecipe recipe = new ShapedRecipe(key, item);

        recipe.shape(
                "ODO",
                "RLR",
                "ODO"
        );

        recipe.setIngredient('O', Material.OBSIDIAN);
        recipe.setIngredient('R', Material.REDSTONE);
        recipe.setIngredient('D', Material.DIAMOND);
        recipe.setIngredient('L', Material.LAVA_BUCKET);

        plugin.getServer().addRecipe(recipe);
    }

    public static void getSandFarmerRecipe() {

        ItemStack item = FarmerBlock.getSandFarmer(1);

        NamespacedKey key = new NamespacedKey(Main.getMain(), "SandFarmer");

        ShapedRecipe recipe = new ShapedRecipe(key, item);

        recipe.shape(
                "SGS",
                "RLR",
                "SGS"
        );

        recipe.setIngredient('S', Material.SAND);
        recipe.setIngredient('R', Material.REDSTONE);
        recipe.setIngredient('G', Material.GOLD_INGOT);
        recipe.setIngredient('L', Material.LAVA_BUCKET);

        plugin.getServer().addRecipe(recipe);
    }

    public static void getKopaczFosy() {

        ItemStack item = FarmerBlock.getKopaczFosy(1);

        NamespacedKey key = new NamespacedKey(Main.getMain(), "KopaczFosy");

        ShapedRecipe recipe = new ShapedRecipe(key, item);

        recipe.shape(
                "SES",
                "EDE",
                "SES"
        );

        recipe.setIngredient('S', Material.STONE);
        recipe.setIngredient('E', Material.EMERALD);
        recipe.setIngredient('D', Material.DIAMOND_PICKAXE);

        plugin.getServer().addRecipe(recipe);
    }
}
