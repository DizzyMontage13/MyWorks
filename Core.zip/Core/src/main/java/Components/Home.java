package Components;

import lombok.Setter;
import org.bukkit.World;

import java.util.UUID;

public class Home {

    private @Setter double adX;
    private @Setter double adY;
    private @Setter double adZ;
    private @Setter String name;
    private @Setter UUID nickname;

    public Home(UUID nickname) {
        this.nickname = nickname;
        this.name = HomeFile.getConfig().getString("Homes." + nickname + ".Name");
        this.adX = HomeFile.getConfig().getDouble("Homes." + nickname + ".X");
        this.adY = HomeFile.getConfig().getDouble("Homes." + nickname + ".Y");
        this.adZ = HomeFile.getConfig().getDouble("Homes." + nickname + ".Z");
    }

    public UUID getNickname() { return this.nickname; }
    public String name() { return this.name; }
    public double getAdX() { return this.adX; }
    public double getAdY() { return this.adY; }
    public double getAdZ() { return this.adZ; }
}
