package Components;

import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Objects;


public class    LocationsData extends DataManager {

    public LocationsData(Main main) {
        super(main, "Locations.yml");
    }

    public String SaveLocationToString(Location location) {

        String world = location.getWorld().getName();
        int x = location.getBlockX();
        int y = location.getBlockY();
        int z = location.getBlockZ();

        return world + ":" + x + ":" + y + ":" + z;
    }

    public void saveLocation(Location location) {
        String string = SaveLocationToString(location);
        config.set("spawn", string);
        save();
    }

    public Location getLocation() {
        String str = config.getString("spawn");
        assert str != null;
        String[] l = str.split(":");

        return new Location(Bukkit.getWorld(l[0]), Integer.parseInt(l[1]), Integer.parseInt(l[2]), Integer.parseInt(l[3]));
    }

    public boolean CheckIfLocationExists() {
        return config.isSet("spawn");
    }
}
