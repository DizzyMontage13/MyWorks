package Components;

public enum DropType {
    CANCEL_DROP("CANCEL_DROP", 0, "CANCEL_DROP", 0),
    NORMAL_DROP("NORMAL_DROP", 1, "NORMAL_DROP", 1),
    RANDOM_DROP("RANDOM_DROP", 2, "RANDOM_DROP", 2);

    DropType(String cancel_drop, int i, String cancel_drop1, int i1) {
    }
}
