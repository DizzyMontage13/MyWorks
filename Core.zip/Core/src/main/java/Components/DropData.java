//package Components;
//
//import Utils.TextUtils;
//import com.Challangerson.Main;
//import org.bukkit.Material;
//import org.bukkit.configuration.ConfigurationSection;
//import org.bukkit.inventory.ItemStack;
//
//import java.util.List;
//import java.util.Objects;
//
//public class DropData extends DataManager {
//
//    public DropData(Main main) {
//        super(main, "drops.yml");
//    }
//
//
//    public double getChance(String name) {
//        return config.getDouble("drops." + name + ".chance");
//    }
//
//    public String getColor(String name) {
//        return config.getString("drops." + name + ".color");
//    }
//
//    public ItemStack getItemStack(String name) {
//        return TextUtils.getItemStackFromString(Objects.requireNonNull(config.getString("drops." + name + ".item")));
//    }
//
//    public List<String> getStringList() { return config.getStringList("cancel-drops"); }
//
//    public Material getMaterial(String name) {
//        return Material.getMaterial(Objects.requireNonNull(config.getString("drops." + name + ".from")));
//    }
//
//
//    public ConfigurationSection getString() {
//        return config.getConfigurationSection("drops");
//    }
//}
