package Components;

import Utils.Randomizer;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class RandomDropData {
    private static final List<Drop> drops = new ArrayList<>();

    private static final Set<UUID> noCobble = new HashSet<>();

    private static final Set<UUID> noInformation = new HashSet<>();

    private static final Set<UUID> ItemsToEq = new HashSet<>();


    public static void changeNoCobble(UUID uuid) {
        if (noCobble.contains(uuid)) {
            noCobble.remove(uuid);
        } else {
            noCobble.add(uuid);
        }
    }

    public static void changeMessages(UUID uuid) {
        if(noInformation.contains(uuid)) {
            noInformation.remove(uuid);
        } else {
            noInformation.add(uuid);
        }
    }

    public static boolean isNoMessages(UUID uuid) { return noInformation.contains(uuid); }

    public static boolean isNoCobble(UUID uuid) {
        return noCobble.contains(uuid);
    }

    public RandomDropData() {
        drops.clear();
        for (String string : DropFile.getConfig().getConfigurationSection("drops").getKeys(false)) {
            Drop drop = new Drop(string);
            drops.add(drop);
        }
    }

    public static Drop getDropByName(String name) {
        for (Drop d : drops) {
            if (d.getName().equalsIgnoreCase(name))
                return d;
        }
        return null;
    }

    public static void CreateDrops() {
        drops.clear();
        for (String string : DropFile.getConfig().getConfigurationSection("drops").getKeys(false)) {
            Drop drop = new Drop(string);
            drops.add(drop);
        }
    }

    private static int getInt(Player player) {
        return player.getInventory().getItemInMainHand().getEnchantmentLevel(Enchantment.LOOT_BONUS_BLOCKS);
    }

    private static double addDropFortune(Player player, double Double) {
        if(getInt(player) == 1) {
            return Double + 1.5;
        } else if (getInt(player) == 2) {
            return Double + 1.8;
        } else if (getInt(player) == 3) {
            return Double + 2;
        } else {
            return Double;
        }
    }

    public static void DropItem(Player player) {
        for(Drop drop : drops) {
            ItemStack itemStack = drop.getWhat().clone();

            double chance = drop.getChance();

            UUID uuid = player.getUniqueId();

            double newChance = chance + addDropFortune(player, chance);

            if(!Randomizer.getChance(newChance)) continue;

            if(drop.isDisabled(uuid)) continue;


            if(player.getInventory().firstEmpty() < 0) {
                player.sendMessage("FULL EQ");
                return;
            }

            player.getInventory().addItem(itemStack);

            if(!noInformation.contains(uuid)) {
                player.sendMessage(TextUtils.corolize("&2&lDROP &7Wydropiles &" + drop.getColor() + drop.getName()));
            }


        }
    }

    public DropType getDropType() {
        return DropType.RANDOM_DROP;
    }

    public static List<Drop> getDrops() {
        return drops;
    }
}
