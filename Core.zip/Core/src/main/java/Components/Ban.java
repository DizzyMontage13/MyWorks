package Components;

import lombok.Getter;

import java.util.UUID;

public class Ban {

    private final @Getter UUID uuid;
    private final @Getter boolean perm;
    private final @Getter long time;


    public Ban(UUID uuid) {
        this.uuid = uuid;
        this.perm = true;
        this.time = 0L;
    }


    public Ban(UUID uuid, boolean perm, long time) {
        this.uuid = uuid;
        this.perm = perm;
        this.time = time;
    }

}
