package Components;

import Utils.TextUtils;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;


public class Drop {


    private final String name;
    private final double chance;
    private final String color;
    private final ItemStack itemStack;
    private final Set<UUID> disabled;



    public Drop(String name) {
        this.name = name;
        this.disabled = new HashSet<>();
        this.itemStack = TextUtils.getItemStackFromString(DropFile.getConfig().getString("drops." + name + ".item"));
        this.color = DropFile.getConfig().getString("drops." + name + ".color");
        this.chance = DropFile.getConfig().getDouble("drops." + name + ".chance");
    }

    public void changeStatus(UUID uuid) {
        if(this.disabled.contains(uuid))  {
            this.disabled.remove(uuid);
        } else {
            this.disabled.add(uuid);
        }
    }

    public void setStatus(UUID uuid, boolean bol) {
        if(bol) {
            if(this.disabled.contains(uuid))  {
                this.disabled.remove(uuid);
            } else if(!this.disabled.contains(uuid)){
                this.disabled.add(uuid);
            }
        }
    }


    public String getName() {
        return this.name;
    }

    public double getChance() {
        return this.chance;
    }

    public String getColor() {
        return this.color;
    }

    public Set<UUID> getDisabled() {
        return this.disabled;
    }

    public boolean isDisabled(UUID uuid) {
        return this.disabled.contains(uuid);
    }

    public ItemStack getWhat() {
        return this.itemStack;
    }

}
