package Components;


import Utils.Enchantments;
import Utils.ItemBuilder;
import Utils.Randomizer;
import Utils.TextUtils;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class CaseDropData {

    private static final List<Case> cases = new ArrayList<>();

    private static final Set<UUID> messages = new HashSet<>();


    public static void ChangeNoMessages(UUID uuid) {
        if(messages.contains(uuid)) {
            messages.remove(uuid);
        } else {
            messages.add(uuid);
        }
    }

    public CaseDropData() {
        cases.clear();
        for(String string : CaseFile.getConfig().getConfigurationSection("case").getKeys(false)) {
            Case c = new Case(string);
            cases.add(c);
        }
    }

    public static void CreateDropCases() {
        cases.clear();
        for(String string : CaseFile.getConfig().getConfigurationSection("case").getKeys(false)) {
            Case c = new Case(string);
            cases.add(c);
        }
    }


    public static void CaseDropItems(Player player, Location location) {
        for(Case c : cases) {

            Material material = c.getMaterial().getType();

            double chance = c.getChance();

            player.sendMessage(" " + c.getLevel());

            if(!Randomizer.getChance(chance)) continue;

            ItemStack itemStack;

            c.getEnchantments(c.getName());

            if(c.getLevel().isEmpty()) {
                itemStack = new ItemBuilder(material).setAmount(c.getAmount()).build();
            } else {
                itemStack = new ItemBuilder(material).setAmount(c.getAmount()).addEnchantments(c.getLevel()).build();
            }



            location.getWorld().dropItemNaturally(location, itemStack);
        }
    }


    public static List<Case> getCases() { return cases; }



}
