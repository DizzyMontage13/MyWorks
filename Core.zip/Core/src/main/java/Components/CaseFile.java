package Components;

import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.logging.Level;

public class CaseFile {
    private static final Main plugin = Main.getMain();

    private static FileConfiguration caseConfig = null;

    private static File caseConfigFile = null;

    public static void reloadConfig() {
        if (caseConfigFile == null)
            caseConfigFile = new File(plugin.getDataFolder(), "case.yml");
        caseConfig = YamlConfiguration.loadConfiguration(caseConfigFile);
        InputStream defConfigStream = plugin.getResource("case.yml");
        if (defConfigStream != null) {
            YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(defConfigStream));
            caseConfig.setDefaults((Configuration)defConfig);
        }
    }

    public static FileConfiguration getConfig() {
        if (caseConfig == null)
            reloadConfig();
        return caseConfig;
    }

    public static void saveConfig() {
        if (caseConfig == null || caseConfigFile == null)
            return;
        try {
            getConfig().save(caseConfigFile);
        } catch (IOException ex) {
            Bukkit.getLogger().log(Level.SEVERE, "Could not save config to " + caseConfigFile, ex);
        }
    }

    public static void saveDefaultConfig() {
        if (caseConfigFile == null)
            caseConfigFile = new File(plugin.getDataFolder(), "case.yml");
        if (!caseConfigFile.exists())
            plugin.saveResource("case.yml", false);
    }
}

