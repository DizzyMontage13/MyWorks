package Components;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class BanManager {

    private final List<Ban> bansList = new ArrayList<>();


    public void BanPlayer(UUID uuid) {

        Ban ban = new Ban(uuid);

        bansList.add(ban);
    }

    public void BanTimePlayer(UUID uuid, long time) {
        Ban ban = new Ban(uuid, false, time);

        bansList.add(ban);

    }


    public boolean CheckPermBan(UUID uuid) {

        Ban ban = new Ban(uuid);

        if(!bansList.contains(ban)) return false;


        return ban.isPerm();
    }


    public long CheckTimeForBan(UUID uuid) {

        if(CheckPermBan(uuid)) return 0L;


        Ban ban = new Ban(uuid);

        return ban.getTime();
    }


    public List<Ban> getBansList() {
        return this.bansList;
    }

}
