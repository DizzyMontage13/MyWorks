package Components;

import Utils.Enchantments;
import Utils.TextUtils;
import org.bukkit.Material;
import org.bukkit.block.Campfire;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import java.io.Console;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Case {

    private final String name;
    private final ItemStack material;
    private final double chance;
    private final int amount;
    private final HashMap<Enchantment, Integer> level;

    public Case(String name) {
        this.name = name;
        this.chance = CaseFile.getConfig().getDouble("case." + name + ".chance");
        this.amount = CaseFile.getConfig().getInt("case." + name + ".amount");
        this.material = TextUtils.getItemStackFromString(CaseFile.getConfig().getString("case." + name + ".item"));
        this.level = new HashMap<>();
    }


    public String getName() { return this.name; }
    public double getChance() { return this.chance; }
    public ItemStack getMaterial() { return this.material; }
    public int getAmount() { return this.amount; }
    public HashMap<Enchantment, Integer> getLevel() { return this.level; }

    public void getEnchantments(String name) {

        List<String> list = CaseFile.getConfig().getStringList("case." + name + ".enchantments");

        if(list.isEmpty()) {
            return;
        }

        for (String s : list) {
            //.replace("[", "").replace("]","")
            String[] split = s.split(":");

            Enchantment enchantment = Enchantment.getByName(split[0]);
            int lvl = Integer.parseInt(split[1]);

            System.out.println("NIE MA ENCHANTOW " + enchantment + ":" + lvl);

            if (enchantment == null) return;

            this.level.put(enchantment, lvl);
        }

    }
}
