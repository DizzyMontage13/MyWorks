package commands.player;

import Utils.TextUtils;
import commands.player.MsgCommand;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class rCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if(sender instanceof Player) {
            Player player = (Player) sender;

            if(MsgCommand.messages.containsKey(player)) {
                Player user = MsgCommand.messages.get(player);

                StringBuilder stringBuilder = new StringBuilder();

                for(int i = 0; i < args.length; i++) {
                    stringBuilder.append(args[i]).append(" ");
                }

                String message;
                if(player.hasPermission("dizzycore.ChatColored") || player.isOp()) {
                    message = TextUtils.corolize(stringBuilder.toString());
                } else {
                    message = stringBuilder.toString();
                }

                player.sendMessage(TextUtils.corolize("&7[ &cTy &7» &e" + user.getName() + " &7] &a▸ &f") + message);
                user.sendMessage(TextUtils.corolize("&7[ &e" + player.getName()  +" &7» &cTy &7] &a▸ &f") + message);
            }
        }

        return  false;
    }
}
