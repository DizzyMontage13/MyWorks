package commands.player;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

public class TpaCommand implements CommandExecutor {


    public static Map<Player, Player> request = new HashMap<>();

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if(sender instanceof Player) {
            Player player = (Player) sender;

            if(args.length == 1) {
                Player cel = Bukkit.getPlayer(args[0]);

                if(cel != null) {
                    if(cel != player) {
                        if (request.containsKey(cel)) {
                            player.sendMessage(TextUtils.Wrong("&7Wyslales juz prosbe o teleportacje do gracza &e" + cel.getName()));
                            // request.remove(cel);
                        } else {
                            request.put(cel, player);
                            player.sendMessage(TextUtils.colorizeWithPrefix("&fWyslano prosbe do gracza &e" + cel.getName()));
                            cel.sendMessage(TextUtils.colorizeWithPrefix("&fOtrzymano prosbe o teleportacje od gracza &e" + player.getName()));
                            cel.sendMessage(TextUtils.corolize(" "));
                            cel.sendMessage(TextUtils.corolize("&7&l» &e/tpaaccept &7(nick) &f - aby zaakceptowac prosbe"));
                            cel.sendMessage(TextUtils.corolize("&7&l» &e/tpadeny &7(nick) &f - aby odrzucic prosbe"));

                            Bukkit.getScheduler().runTaskLater(Main.getMain(), () -> {
                                if (request.containsKey(cel)) {
                                    request.remove(cel);
                                    player.sendMessage(TextUtils.Wrong("&7Teleportacja przedawniona"));
                                }
                            }, 300L);
                            return true;
                        }
                    } else {
                        player.sendMessage(TextUtils.Wrong("&7Nie możesz teleportować się sam do siebie!"));
                        return false;
                    }
                } else {
                    player.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                    return false;
                }

            } else {
                player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/tpa (nick)"));
                return false;
            }
        }
        return false;
    }
}
