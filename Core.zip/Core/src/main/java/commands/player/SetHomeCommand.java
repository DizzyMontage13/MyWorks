package commands.player;

import Components.HomeManager;
import Utils.TextUtils;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class SetHomeCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {

        if(!(sender instanceof Player))
            return false;

        Player player = (Player) sender;
        UUID uuid = player.getUniqueId();
        if(args.length > 0) {

            HomeManager homeManager = new HomeManager();

            if(homeManager.HomeExist(uuid))
                return false;

            Location location = player.getLocation();

            homeManager.setHomes(uuid, location);

            player.sendMessage(TextUtils.colorizeWithPrefix("&a&lPomyslnie &fustawiono home!"));


        } else {
            player.sendMessage(TextUtils.Wrong("&fPoprawne uzycie &f/sethome"));
        }

        return false;
    }
}
