package commands.player;

import Inventories.Test;
import Utils.TextUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HelpCommand implements CommandExecutor {





    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {

        if(sender instanceof Player) {
            Player player = (Player) sender;



            player.sendMessage(TextUtils.corolize("&7&l=-=-=-=-=-=-=-=-=-=  &c&lPOMOC  &7&l=-=-=-=-=-=-=-=-=-="));
            player.sendMessage(" ");
            player.sendMessage(TextUtils.corolize("&7&l» &e/vip &7- &fZobacz co posiada ranga Vip"));
            player.sendMessage(TextUtils.corolize("&7&l» &e/svip &7- &fZobacz co posiada ranga SVip"));
            player.sendMessage(TextUtils.corolize("&7&l» &e/drop &7- &fZobacz jaki procent jest na drop ze stone"));
            player.sendMessage(TextUtils.corolize("&7&l» &e/g &7- &fDowiedz sie więcej o gildiach"));
            player.sendMessage(TextUtils.corolize("&7&l» &e/helpop &7- &fZgłoś cheatera"));
            player.sendMessage(" ");
            player.sendMessage(" ");
            player.sendMessage(TextUtils.corolize("&e&lSTRONA : &fSalkmc.pl"));
            player.sendMessage(TextUtils.corolize("&e&lDiscord : &fSalkmc.pl/dsc"));
            player.sendMessage(TextUtils.corolize("&e&lFB : &fSalkmc.pl/fb"));
            player.sendMessage(" ");
            player.sendMessage(" ");
            player.sendMessage(TextUtils.corolize("&7&l=-=-=-=-=-=-=-=-=-=  &c&lPOMOC  &7&l=-=-=-=-=-=-=-=-=-="));


        }
        return false;
    }
}
