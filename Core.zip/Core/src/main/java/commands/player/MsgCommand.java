package commands.player;

import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashMap;

public class MsgCommand implements CommandExecutor {

    public static HashMap<Player, Player> messages = new HashMap<>();

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {

        if(sender instanceof Player) {
            Player player = (Player) sender;
            if(args.length >= 2) {
                Player user = Bukkit.getPlayer(args[0]);
                if(user != player) {
                    if(user != null) {
                        StringBuilder stringBuilder = new StringBuilder();

                        for(int i = 1; i < args.length; i++) {
                            stringBuilder.append(args[i]).append(" ");
                        }


                        String message;
                        if(player.hasPermission("dizzycore.ChatColored") || player.isOp()) {
                            message = TextUtils.corolize(stringBuilder.toString());
                        } else {
                            message = stringBuilder.toString();
                        }

                        player.sendMessage(TextUtils.corolize("&7[ &cTy &7» &e" + user.getName() + " &7] &a▸ &f") + message);
                        user.sendMessage(TextUtils.corolize("&7[ &e" + player.getName()  +" &7» &cTy &7] &a▸ &f") + message);

                        messages.put(user, player);
                        messages.put(player, user);

                    } else {
                        sender.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                    }
                } else {
                    sender.sendMessage(TextUtils.Wrong("&7Nie mozesz wyslac wiadomosci sam do siebie"));
                }
            } else {
                sender.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/msg <Gracz> (wiadomosc)"));
            }
        }

        return false;
    }
}
