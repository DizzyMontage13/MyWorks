package commands.player;

import Inventories.DropGui;
import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DropCommand implements CommandExecutor {


    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {

        if(sender instanceof Player) {

            Player player = (Player) sender;

            if(args.length == 1) {

                if(!player.isOp()) {
                    player.sendMessage(TextUtils.Wrong("&7Nie masz permisji"));
                    return false;
                }

                Player user = Bukkit.getPlayer(args[0]);

                if(user == null) {
                    player.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                    return false;
                }

                player.sendMessage(TextUtils.corolize("&a&lSUKCES! &7Dodano gracza &e+" + user.getName() + "&7 do bazy!"));

            } else {
                DropGui.DropInventory(player);
            }

        }

        return false;
    }
}
