package commands.player;

import Inventories.KitsGui;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KitCommand implements CommandExecutor {


    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if(sender instanceof Player) {

            Player player = (Player) sender;

            if(!Main.getMain().getConfig().getBoolean("kits")) {
                player.sendMessage(TextUtils.Wrong("&a&lKITY &7są &c&lWYŁĄCZONE!"));
                return false;
            }

            player.openInventory(KitsGui.openKitGui(player));
            return true;
        }
        return false;
    }
}
