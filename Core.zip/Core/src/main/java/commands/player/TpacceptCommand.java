package commands.player;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;

public class TpacceptCommand implements CommandExecutor {

    public static HashMap<Player,Player> tpacceptrequest = new HashMap<>();

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
            Player player = (Player) sender;

            if(args.length == 1) {
                Player player1 = Bukkit.getPlayer(args[0]);

                if(TpaCommand.request.containsKey(player)) {
                    Player user = TpaCommand.request.get(player);
                    if(user == player1) {

                        if(tpacceptrequest.containsKey(player)) {
                            player.sendMessage(TextUtils.corolize("WLASNIE SIE TELEPORTUJESZ"));
                            return false;
                        }

                            new BukkitRunnable() {

                            int i = 0;

                            @Override
                            public void run() {
                                if(TpacceptCommand.tpacceptrequest.containsKey(user)) {
                                    i ++;
                                    if(i == 10) {
                                        user.teleport(player);
                                        user.sendMessage(TextUtils.corolize("&a&lSukces! &7Zostales przeteleportowany"));
                                        TpaCommand.request.remove(player, user);
                                        TpacceptCommand.tpacceptrequest.remove(user , player);
                                        i = 0;
                                        user.removePotionEffect(PotionEffectType.BLINDNESS);
                                        user.removePotionEffect(PotionEffectType.SLOW);
                                        this.cancel();
                                    }
                                } else {
                                    user.sendMessage(TextUtils.Wrong("&7Ruszyles sie podczas teleportacji"));
                                    TpaCommand.request.remove(player, user);
                                    TpacceptCommand.tpacceptrequest.remove(user , player);
                                    user.removePotionEffect(PotionEffectType.BLINDNESS);
                                    user.removePotionEffect(PotionEffectType.SLOW);

                                    i= 0;

                                    this.cancel();
                                }

                            }
                        }.runTaskTimer(Main.getMain(), 0, 10L);


                        user.sendMessage(TextUtils.colorizeWithPrefix("&fGracz &e" + player.getName() + "&f zaakceptowal. Zostaniesz przeteleportowany za &c5 &fsekund!"));
                        player.sendMessage(TextUtils.colorizeWithPrefix("&aZaakceptowano &fprosbe od gracza &e"+ user.getName()));
                        // user = teleportujacy , player = akceptujacy
                        tpacceptrequest.put(user ,player);

                    } else {
                        player.sendMessage(TextUtils.Wrong("&7Nie masz prosby od tego gracza"));
                    }
                } else {
                    player.sendMessage(TextUtils.Wrong("&7Nie masz prosby do zaakceptowania"));
                }
            } else {
                player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/tpaccept (nick)"));
            }
            return false;
    }

}
