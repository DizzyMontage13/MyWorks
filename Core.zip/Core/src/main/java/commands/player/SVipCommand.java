package commands.player;

import Utils.TextUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SVipCommand implements CommandExecutor {


    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if(sender instanceof Player) {
            Player player = (Player) sender;

            player.sendMessage(" ");
            player.sendMessage(TextUtils.corolize("&7&l=-=-=-=-=-=-=-=-=-=  &5&lS&6&lVIP  &7&l=-=-=-=-=-=-=-=-=-="));
            player.sendMessage(" ");
            player.sendMessage(TextUtils.corolize("&7&l» &fRanga SVip posiada prefix : &7[ &5&lS&6&lVIP &7] &e" +
                    player.getName() + " &7&l» &eSalkMC.pl jest najlepszy"));
            player.sendMessage(TextUtils.corolize("&7&l» &fRanga SVip posiada zestaw SVip"));
            player.sendMessage(TextUtils.corolize("&7&l» &fRanga SVip posiada 3 sethome'y"));
            player.sendMessage(TextUtils.corolize("&7&l» &fRanga SVip ma 50% mniej itemow na gildie"));
            player.sendMessage(TextUtils.corolize("&7&l» &fRanga SVip posiada 30% więcej do dropu"));
            player.sendMessage(TextUtils.corolize("&7&l» &fDostęp do komend : &e/ec , /wb"));
            player.sendMessage(TextUtils.corolize("&7&l» &fRanga SVip posiada powiększy enderchest"));
            player.sendMessage(" ");
            player.sendMessage(TextUtils.corolize("&7&l» &f Range zakupisz na stronie : &eSALKMC.PL"));
            player.sendMessage(" ");
            player.sendMessage(TextUtils.corolize("&7&l=-=-=-=-=-=-=-=-=-=  &5&lS&6&lVIP  &7&l=-=-=-=-=-=-=-=-=-="));
            player.sendMessage(" ");




        }


        return false;
    }
}
