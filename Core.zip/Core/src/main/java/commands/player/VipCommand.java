package commands.player;

import Utils.TextUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class VipCommand implements CommandExecutor {


    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if(sender instanceof Player) {
            Player player = (Player) sender;

            player.sendMessage(TextUtils.corolize("&7&l=-=-=-=-=-=-=-=-=-=  &6&lVIP  &7&l=-=-=-=-=-=-=-=-=-="));
            player.sendMessage(" ");
            player.sendMessage(TextUtils.corolize("&7&l» &fRanga Vip posiada prefix : &7[ &6&lVIP &7] &e" +
                    player.getName() + " &7&l» &eSalkMC.pl jest najlepszy"));
            player.sendMessage(TextUtils.corolize("&7&l» &fRanga Vip posiada zestaw Vip"));
            player.sendMessage(TextUtils.corolize("&7&l» &fRanga Vip posiada 2 sethome'y"));
            player.sendMessage(TextUtils.corolize("&7&l» &fRanga Vip ma 50% mniej itemow na gildie"));
            player.sendMessage(TextUtils.corolize("&7&l» &fRanga Vip posiada 30% więcej do dropu"));
            player.sendMessage(TextUtils.corolize("&7&l» &fDostęp do komend : &e/ec , /wb"));
            player.sendMessage(" ");
            player.sendMessage(TextUtils.corolize("&7&l» &f Range zakupisz na stronie : &eSALKMC.PL"));
            player.sendMessage(" ");
            player.sendMessage(TextUtils.corolize("&7&l=-=-=-=-=-=-=-=-=-=  &6&lVIP  &7&l=-=-=-=-=-=-=-=-=-="));




        }


        return false;
    }
}
