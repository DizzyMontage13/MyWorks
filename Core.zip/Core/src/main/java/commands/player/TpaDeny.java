package commands.player;

import Utils.TextUtils;
import commands.player.TpaCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TpaDeny implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;

            if(args.length == 1) {
                Player cel = Bukkit.getPlayer(args[0]);

                //player cel
                if(TpaCommand.request.containsKey(player)) {
                    Player cel1 = TpaCommand.request.get(player);


                    if(cel == cel1) {
                            TpaCommand.request.remove(player);


                            assert cel != null;
                            player.sendMessage(TextUtils.Wrong("&7Odrzuciles prosbe od gracza &e" + cel.getName()));
                            cel1.sendMessage(TextUtils.Wrong("&7Gracz &e" + player.getName() + "&7 odrzucil twoja prosbe"));


                    } else {
                        player.sendMessage(TextUtils.Wrong("&7Nie masz prosby od tego gracza"));
                    }
                } else {
                    TextUtils.Wrong("&7Nie masz zadnej prosby do odrzucenia");
                }
            } else {
                player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/tpadeny (nick)"));
            }
        }
        return false;
    }
}
