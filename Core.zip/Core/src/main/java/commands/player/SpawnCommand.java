package commands.player;

import Components.LocationsData;
import Events.MoveOnTeleport;
import Utils.TextUtils;
import Utils.TitleAPI;
import com.Challangerson.Main;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class SpawnCommand implements CommandExecutor {

    LocationsData locationsData;

    Main plugin;

    public SpawnCommand(Main main) {
        plugin = main;
        this.locationsData = new LocationsData(main);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;

                if(MoveOnTeleport.spawnCommand.contains(player)) {
                    player.sendMessage(TextUtils.Wrong("&7Aktualnie jestes teleportowany!"));
                    return false;
                }

                MoveOnTeleport.spawnCommand.add(player);

                new BukkitRunnable() {

                    int BackToSpawn = 6;

                    @Override
                    public void run() {

                        if(MoveOnTeleport.spawnCommand.contains(player)) {
                            BackToSpawn--;

                            TitleAPI.SendActionBar(
                                    player,
                                    TextUtils.corolize("&7&l» &fPrzeteleportowanie na spawna nastąpi za &e"+ BackToSpawn + "&f sekund &7&l«")
                            );

                            if(BackToSpawn == 0) {
                                TitleAPI.SendActionBar(player, TextUtils.colorizeWithPrefix("&7&l» &fPrzeteleportowano na &a&lSPAWNA &7&l«"));
                                player.teleport(locationsData.getLocation());
                                BackToSpawn = 6;
                                this.cancel();
                                MoveOnTeleport.spawnCommand.remove(player);
                            }
                        } else {
                            TitleAPI.SendActionBar(player, "&7&l» &f&lTELEPORT &4&lPRZERWANY &7&l«");
                            BackToSpawn = 6;
                            this.cancel();
                        }
                    }
                }.runTaskTimer(plugin, 0L, 20L);
            }
        return false;
    }
}
