package commands.admin;

import Inventories.AdminPanelGui;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AdminPanelCommand implements CommandExecutor {




    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if(sender instanceof Player) {
            Player player = (Player) sender;

            if(!player.isOp() || !player.hasPermission("dizzycore.adminpanel")) return false;

            player.openInventory(AdminPanelGui.OpenInventoryAdminPanelGui(player));

        }



        return false;
    }
}
