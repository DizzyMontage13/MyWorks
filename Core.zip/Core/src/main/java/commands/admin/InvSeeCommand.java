package commands.admin;

import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;

public class InvSeeCommand implements CommandExecutor {

    ArrayList<Player> arrayList = new ArrayList<>();

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (sender instanceof Player) {
            Player player = (Player) sender;


            arrayList.addAll(Bukkit.getOnlinePlayers());



            if(!player.isOp() || !player.hasPermission("dizzycore.adminpanel")) return false;

            if (args.length == 1) {

                Player user = Bukkit.getPlayerExact(args[0]);

                if(user == null) {
                    player.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                    return false;
                }

                player.openInventory(user.getInventory());
                sender.sendMessage(TextUtils.colorizeWithPrefix("&7Otworzyles &fEQ &7gracza &a" + user.getDisplayName()));
            } else {
                player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/invsee (nick)"));
            }
        }
        return false;
    }
}

