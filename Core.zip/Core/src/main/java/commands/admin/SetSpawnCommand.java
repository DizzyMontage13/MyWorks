package commands.admin;

import Components.LocationsData;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetSpawnCommand implements CommandExecutor {

    LocationsData locationsData;

    Main plugin;

    public SetSpawnCommand(Main main) {
        plugin = main;
        this.locationsData = new LocationsData(main);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if (sender instanceof Player) {


            Player player = (Player) sender;

            if(player.hasPermission("dizzyCore.setspawn") || player.isOp()) {
                Location location = player.getLocation();
                locationsData.saveLocation(location);

                player.sendMessage(TextUtils.colorizeWithPrefix("&fPomyslnie ustawiono &a&lSPAWNA"));

            }

        }
        return false;
    }
}
