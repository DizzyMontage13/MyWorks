package commands.admin;

import Utils.PremiumCaseBlock;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PremiumCaseCommand implements CommandExecutor {


    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {

        if(sender instanceof Player) {
            Player player = (Player) sender;

            if(player.hasPermission("dizzycore.premiumcase") || player.isOp()) {
                if(args.length == 2) {
                    if(args[0].equals("all")) {

                        if(!TextUtils.isInteger(args[1])) {
                            player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/case <all / nick> < ilosc >"));
                            return false;
                        }

                        int amount = Integer.parseInt(args[1]);

                        for(Player players : Bukkit.getServer().getOnlinePlayers())
                        {



                            players.sendTitle(TextUtils.corolize("&7&l✘✘ &c&lUWAGA &7&l✘✘"),
                                    TextUtils.corolize("&7&l» &eZa &a&l5 &esekund zostana rozdane &5&lMystery Barrels &e〤 &c" + amount + " &7&l«"),
                                    20, 40, 20);

                            Bukkit.getScheduler().runTaskLater(Main.getMain(), () -> {
                                players.getInventory().addItem(PremiumCaseBlock.getPremiumCases(amount));
                                Location location = players.getLocation();

                                players.playSound(location, Sound.ENTITY_VILLAGER_YES, 10, 1);
                            }, 160L);
                        }

                    } else {
                        Player cel = Bukkit.getPlayerExact(args[0]);

                        if(!TextUtils.isInteger(args[1])) {
                            player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/case <all / nick> < ilosc >"));
                            return false;
                        }

                        if(cel != null && cel.isOnline()) {
                            int amount = Integer.parseInt(args[1]);
                            cel.sendMessage(TextUtils.colorizeWithPrefix("&7Otrzymano " + amount + " &5&lMystery Barrels'ow "));
                            cel.getInventory().addItem(PremiumCaseBlock.getPremiumCases(amount));
                        } else {
                            player.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                        }
                    }
                } else {
                    player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/case <all / nick> < ilosc >"));
                }
            } else {
                player.sendMessage(TextUtils.Wrong("&7Nie masz uprawnien do tej komendy!"));
            }


        }
        return false;
    }
}
