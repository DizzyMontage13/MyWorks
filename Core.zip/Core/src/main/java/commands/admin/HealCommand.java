package commands.admin;

import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;

public class HealCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {


        if(sender instanceof Player) {
            Player player = (Player) sender;

            if (player.hasPermission("dizzyCore.heal") || player.isOp()) {
                if (args.length == 1) {
                    Player cel = Bukkit.getPlayer(args[0]);

                    if(cel != null && cel.isOnline()) {
                        cel.setHealth(20);
                        cel.setFoodLevel(20);

                        for(PotionEffect potionEffect : cel.getActivePotionEffects()) {
                            cel.removePotionEffect(potionEffect.getType());
                        }

                        player.sendMessage(TextUtils.colorizeWithPrefix("&7Gracz " + cel.getName() + " &7otrzymal &a&lHEAL'a"));
                        cel.sendMessage(TextUtils.colorizeWithPrefix("&7Otrzymales &a&lHEAL'a"));
                    } else {
                        player.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                    }
                } else {
                    player.setHealth(20);
                    player.setFoodLevel(20);

                    for(PotionEffect potionEffect : player.getActivePotionEffects()) {
                        player.removePotionEffect(potionEffect.getType());
                    }

                    player.sendMessage(TextUtils.colorizeWithPrefix("&7Otrzymales &a&lHEAL'a"));
                }
            } else {
                player.sendMessage(TextUtils.Wrong("&7Nie masz uprawnien do tej komendy!"));
            }
        }
        return false;
    }
}
