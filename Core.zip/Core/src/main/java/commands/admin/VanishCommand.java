package commands.admin;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;

public class VanishCommand  implements CommandExecutor {

    public ArrayList<Player> invisible_players = new ArrayList<>();

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;

            if(player.isOp() || player.hasPermission("dizzycore.vanish")) {
                if(args.length == 1) {
                    String str = args[0];
                    if(!str.equalsIgnoreCase("status")) return false;

                    if(invisible_players.contains(player)) {
                        player.sendMessage(TextUtils.corolize("&a&lVANISH &7Status &a&lWLACZONY"));
                    } else {
                        player.sendMessage(TextUtils.corolize("&a&lVANISH &7Status &c&lWYLACZONY"));
                    }
                    return true;
                } else {
                    if(invisible_players.contains(player)) {
                        for(Player players : Bukkit.getOnlinePlayers()) {
                            players.showPlayer(Main.getMain(), player);
                        }

                        invisible_players.remove(player);
                        player.sendTitle(TextUtils.corolize("&7&l✘✘ &a&lVANISH &7&l✘✘"),
                                TextUtils.corolize("&7&l» &fVanish zostal &c&lWYLACZAONY"), 10, 20, 10);
                    } else {
                        for(Player players : Bukkit.getOnlinePlayers()) {
                            players.hidePlayer(Main.getMain(), player);
                        }

                        player.sendTitle(TextUtils.corolize("&7&l✘✘ &a&lVANISH &7&l✘✘"),
                                TextUtils.corolize("&7&l» &fVanish zostal &a&lWLACZONY"), 10, 20, 10);
                        invisible_players.add(player);
                    }
                    return true;
                }
            }
        }
        return false;
    }
}
