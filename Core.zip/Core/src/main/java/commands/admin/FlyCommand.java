package commands.admin;

import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;

public class FlyCommand implements CommandExecutor {

    public ArrayList<Player> PlayerFly = new ArrayList<>();

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {

            if(sender.hasPermission("dizzyCore.fly") || sender.isOp()) {

                if(args.length == 1) {
                    Player user = Bukkit.getPlayer(args[0]);

                    if(user != null && user.isOnline()) {
                        if(PlayerFly.contains(user)) {
                            PlayerFly.remove(user);
                            sender.sendMessage(TextUtils.corolize("&7&l» &fZabrano moc latania graczu: &e" + user.getName()));
                            user.sendTitle(TextUtils.corolize("&7&l✘✘ &a&lFLY &7&l✘✘"),
                                    TextUtils.corolize("&7&l» &fZabrano ci moc latania! "),10,20,10);
                            user.setAllowFlight(false);
                        } else if(!PlayerFly.contains(user)) {
                            PlayerFly.add(user);
                            sender.sendMessage(TextUtils.corolize("&7&l» &fNadano moc latania graczu: &e" + user.getName()));
                            user.sendTitle(TextUtils.corolize("&7&l✘✘ &a&lFLY &7&l✘✘"),
                                    TextUtils.corolize("&7&l» &fNadano ci moc latania! "),10,20,10);
                            user.setAllowFlight(true);
                        }
                    }
                } else {
                    if(sender instanceof Player) {

                        Player player = (Player) sender;

                        if(PlayerFly.contains(player)) {
                            PlayerFly.remove(player);
                            player.sendTitle(TextUtils.corolize("&7&l✘✘ &a&lFLY &7&l✘✘"),
                                    TextUtils.corolize("&7&l» &fZabrano ci moc latania! "),10,20,10);
                            player.setAllowFlight(false);
                        } else if(!PlayerFly.contains(player)){
                            PlayerFly.add(player);
                            player.sendTitle(TextUtils.corolize("&7&l✘✘ &a&lFLY &7&l✘✘"),
                                    TextUtils.corolize("&7&l» &fNadano ci moc latania! "),10,20,10);
                            player.setAllowFlight(true);
                        }
                    } else {
                        sender.sendMessage(TextUtils.corolize("&4&lPrzez console mozesz uzyc tylko /fly (nick)"));
                    }
            }
            } else {
                sender.sendMessage(TextUtils.Wrong("&7Nie masz uprawnien do tej komendy!"));
            }

        return false;
    }
}
