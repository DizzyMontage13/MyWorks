package commands.admin;

import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;


public class TpCommand implements CommandExecutor {


    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {

        if(sender.isOp() || sender.hasPermission("dizzyCore.tp")) {
            if(args.length == 4) {
                if(TextUtils.isInteger(args[1]) && TextUtils.isInteger(args[2]) && TextUtils.isInteger(args[3])) {
                    Player cel = Bukkit.getPlayer(args[0]);

                    int intx = Integer.parseInt(args[1]);
                    int inty = Integer.parseInt(args[2]);
                    int intz = Integer.parseInt(args[3]);



                    if(cel != null && cel.isOnline()) {
                        World world = cel.getWorld();
                        Location location = new Location(world, intx, inty, intz);

                        cel.teleport(location);

                        cel.sendMessage(TextUtils.colorizeWithPrefix("&7Przeteleportowano gracza &c" + cel.getName() + " &7na kordynaty : &ex: "
                                + intx + "&7, &ey: " + inty + "&7, &ez" + intz));
                    } else {
                        sender.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                    }
                } else {
                    sender.sendMessage(TextUtils.Wrong("&7 Poprawne uzycie &f/tp (kordynaty/gracz) (gracz/kordynaty)"));
                }
            } else if (args.length == 3) {
                if(sender instanceof Player) {
                    Player player = (Player) sender;


                    if(TextUtils.isInteger(args[0]) && TextUtils.isInteger(args[1]) && TextUtils.isInteger(args[2])) {

                        int intx = Integer.parseInt(args[0]);
                        int inty = Integer.parseInt(args[1]);
                        int intz = Integer.parseInt(args[2]);

                        World world = player.getWorld();

                        Location location = new Location(world, intx, inty, intz);
                        player.teleport(location);

                        player.sendMessage(TextUtils.colorizeWithPrefix("&7Przeteleportowano cie na kordynaty : &ex: "
                                + intx + "&7, &ey: " + inty + "&7, &ez" + intz));

                    } else {
                        player.sendMessage(TextUtils.Wrong("&7 Poprawne uzycie &f/tp (kordynaty/gracz) (gracz/kordynaty)"));
                    }

                } else {
                    sender.sendMessage(TextUtils.Wrong("&7Ta komende moze uzyc tylko &egracz"));
                }
            } else if(args.length == 1) {
                if(sender instanceof Player) {
                    Player player = (Player) sender;

                    if(!TextUtils.isInteger(args[0])) {

                        Player cel = Bukkit.getPlayer(args[0]);

                        if(cel != null && cel.isOnline()) {
                            player.teleport(cel);

                            player.sendMessage(TextUtils.colorizeWithPrefix("&7Przeteleportowano cie do gracza &e" + cel.getName()));
                        } else {
                            sender.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                        }
                    } else {
                        player.sendMessage(TextUtils.Wrong("&7 Poprawne uzycie &f/tp (kordynaty/gracz) (gracz/kordynaty)"));
                    }
                } else {
                    sender.sendMessage(TextUtils.Wrong("&7Ta komende moze uzyc tylko &egracz"));
                }
            } else if(args.length == 2) {
                Player cel1 = Bukkit.getPlayer(args[0]);
                Player cel2 = Bukkit.getPlayer(args[1]);


                if(!TextUtils.isInteger(args[0]) && !TextUtils.isInteger(args[1])) {
                    if(cel1 != null && cel2 != null && cel2.isOnline() && cel1.isOnline()) {
                        Location cel2location = cel2.getLocation();

                        cel1.teleport(cel2location);

                        cel1.sendMessage(TextUtils.colorizeWithPrefix("&7Przeteleportowano cie do gracza &e" + cel2.getName()));
                        cel2.sendMessage(TextUtils.colorizeWithPrefix("&7Gracz &e" + cel1.getName() + " &7przetelepotowal sie do ciebie!"));
                    } else {
                        sender.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                    }
                }else {
                    sender.sendMessage(TextUtils.Wrong("&7 Poprawne uzycie &f/tp (kordynaty/gracz) (gracz/kordynaty)"));
                }
            } else {
                sender.sendMessage(TextUtils.Wrong("&7 Poprawne uzycie &f/tp (kordynaty/gracz) (gracz/kordynaty)"));
            }
        } else {
            sender.sendMessage(TextUtils.Wrong("&7Nie masz uprawnien"));
        }

        return false;
    }
}
