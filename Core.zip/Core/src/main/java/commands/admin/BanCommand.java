package commands.admin;

import Components.BanManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class BanCommand implements CommandExecutor {


    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {

        if(!(sender instanceof Player)) return false;

        if(args.length == 1) {
            Player cel = Bukkit.getPlayer(args[0]);
            UUID uuid = cel.getUniqueId();

            BanManager banManager = new BanManager();

        }

        return false;
    }
}

