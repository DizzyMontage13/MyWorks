package commands.admin;

import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GamemodeCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {



            if (sender.hasPermission("dizzyCore.gamemode") || sender.isOp()) {
                if (args.length == 1) {
                    if (sender instanceof Player) {
                        Player player = (Player) sender;

                        if (!TextUtils.isInteger(args[0])) {
                            player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/gamemode <0,1,2,3> (gracz)"));
                            return false;
                        }

                        int x = Integer.parseInt(args[0]);

                        switch (x) {
                            case 0:
                                player.setGameMode(GameMode.SURVIVAL);
                                player.sendTitle(TextUtils.corolize("&7&l✘✘ &c&lGamemode &7&l✘✘"),
                                        TextUtils.corolize("&7&l» &fTwoj tryb gry zostal zmieniony na &e&lSURVIVAL"), 10, 20, 10);
                                break;

                            case 1:
                                player.setGameMode(GameMode.CREATIVE);
                                player.sendTitle(TextUtils.corolize("&7&l✘✘ &c&lGamemode &7&l✘✘"),
                                        TextUtils.corolize("&7&l» &fTwoj tryb gry zostal zmieniony na &c&lKREATYWNY"), 10, 20, 10);
                                break;
                            case 2:
                                player.setGameMode(GameMode.ADVENTURE);
                                player.sendTitle(TextUtils.corolize("&7&l✘✘ &c&lGamemode &7&l✘✘"),
                                        TextUtils.corolize("&7&l» &fTwoj tryb gry zostal zmieniony na &e&lPRZYGODOWY"), 10, 20, 10);
                                break;
                            case 3:
                                player.setGameMode(GameMode.SPECTATOR);
                                player.sendTitle(TextUtils.corolize("&7&l✘✘ &c&lGamemode &7&l✘✘"),
                                        TextUtils.corolize("&7&l» &fTwoj tryb gry zostal zmieniony na &a&lSPECTATOR'a"), 10, 20, 10);
                                break;

                            default:
                                player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/gamemode <0,1,2,3> (gracz)"));
                                break;
                        }
                    } else {
                        sender.sendMessage(TextUtils.corolize("&4&lPrzez console mozesz uzyc tylko /gamemode <0,1,2,3> (nick)"));
                    }



                } else if (args.length == 2) {
                    if(!TextUtils.isInteger(args[0])) {
                        sender.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/gamemode <0,1,2,3> (gracz)"));
                        return false;
                    }

                    int x = Integer.parseInt(args[0]);
                    Player cel = Bukkit.getPlayer(args[1]);


                    if(cel != null && cel.isOnline()) {
                        switch (x) {
                            case 0:
                                sender.sendMessage(TextUtils.colorizeWithPrefix("&7Zmieniono tryb gry graczowi : &a" + cel.getName() + " &7na tryb &eSURVIVAL"));
                                cel.setGameMode(GameMode.SURVIVAL);
                                cel.sendTitle(TextUtils.corolize("&7&l✘✘ &c&lGamemode &7&l✘✘"),
                                        TextUtils.corolize("&7&l» &fTwoj tryb gry zostal zmieniony na &e&lSURVIVAL"), 10, 20, 10);
                                break;

                            case 1:
                                sender.sendMessage(TextUtils.colorizeWithPrefix("&7Zmieniono tryb gry graczowi : &a" + cel.getName() + " &7tryb &eCreative"));
                                cel.setGameMode(GameMode.CREATIVE);
                                cel.sendTitle(TextUtils.corolize("&7&l✘✘ &c&lGamemode &7&l✘✘"),
                                        TextUtils.corolize("&7&l» &fTwoj tryb gry zostal zmieniony na &c&lKREATYWNY"), 10, 20, 10);
                                break;
                            case 2:
                                sender.sendMessage(TextUtils.colorizeWithPrefix("&7Zmieniono tryb gry graczowi : &a" + cel.getName() + " &7tryb &ePrzygodowy"));
                                cel.setGameMode(GameMode.ADVENTURE);
                                cel.sendTitle(TextUtils.corolize("&7&l✘✘ &c&lGamemode &7&l✘✘"),
                                        TextUtils.corolize("&7&l» &fTwoj tryb gry zostal zmieniony na &e&lPRZYGODOWY"), 10, 20, 10);
                                break;
                            case 3:
                                sender.sendMessage(TextUtils.colorizeWithPrefix("&7Zmieniono tryb gry graczowi : &a" + cel.getName() + " &7tryb &eSpectator"));
                                cel.setGameMode(GameMode.SPECTATOR);
                                cel.sendTitle(TextUtils.corolize("&7&l✘✘ &c&lGamemode &7&l✘✘"),
                                        TextUtils.corolize("&7&l» &fTwoj tryb gry zostal zmieniony na &a&lSPECTATOR'a"), 10, 20, 10);
                                break;

                            default:
                                sender.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/gamemode <0,1,2,3> (gracz)"));
                                break;
                        }
                    } else {
                        sender.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                    }

                } else {
                    sender.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/gamemode <0,1,2,3> (gracz)"));
                }
            } else {
                sender.sendMessage(TextUtils.Wrong("&7Nie masz uprawnien do tej komendy!"));
            }

        return false;
    }
}
