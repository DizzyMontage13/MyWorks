package commands.admin;

import Utils.TextUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpeedCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            if(args.length == 1) {
                String speed = args[0];

                if(TextUtils.isInteger(speed)) {

                    int tspeed = Integer.parseInt(speed);

                    if(player.isFlying()) {
                        switch (tspeed) {
                            case 1:
                                player.setFlySpeed(0.1F);
                                SendTitleAboutSpeed(1, player, true);
                                break;
                            case 2:
                                player.setFlySpeed(0.2F);
                                SendTitleAboutSpeed(2, player, true);
                                break;
                            case 3:
                                player.setFlySpeed(0.3F);
                                SendTitleAboutSpeed(3, player, true);
                                break;
                            case 4:
                                player.setFlySpeed(0.4F);
                                SendTitleAboutSpeed(4, player, true);
                                break;
                            case 5:
                                player.setFlySpeed(0.5F);
                                SendTitleAboutSpeed(5, player, true);
                                break;
                            case 6:
                                player.setFlySpeed(0.6F);
                                SendTitleAboutSpeed(6, player, true);
                                break;
                            case 7:
                                player.setFlySpeed(0.7F);
                                SendTitleAboutSpeed(7, player, true);
                                break;
                            case 8:
                                player.setFlySpeed(0.8F);
                                SendTitleAboutSpeed(8, player, true);
                                break;
                            case 9:
                                player.setFlySpeed(0.9F);
                                SendTitleAboutSpeed(9, player, true);
                                break;
                            case 10:
                                player.setFlySpeed(1F);
                                SendTitleAboutSpeed(10, player, true);
                                break;
                            case 0:
                                player.setFlySpeed(0F);
                                SendTitleAboutSpeed(0, player, true);
                                break;
                        }
                    } else {
                        switch (tspeed) {
                            case 1:
                                player.setWalkSpeed(0.1F);
                                SendTitleAboutSpeed(1, player, false);
                                break;
                            case 2:
                                player.setWalkSpeed(0.2F);
                                SendTitleAboutSpeed(2, player, false);
                                break;
                            case 3:
                                player.setWalkSpeed(0.3F);
                                SendTitleAboutSpeed(3, player, false);
                                break;
                            case 4:
                                player.setWalkSpeed(0.4F);
                                SendTitleAboutSpeed(4, player, false);
                                break;
                            case 5:
                                player.setWalkSpeed(0.5F);
                                SendTitleAboutSpeed(5, player, false);
                                break;
                            case 6:
                                player.setWalkSpeed(0.6F);
                                SendTitleAboutSpeed(6, player, false);
                                break;
                            case 7:
                                player.setWalkSpeed(0.7F);
                                SendTitleAboutSpeed(7, player, false);
                                break;
                            case 8:
                                player.setWalkSpeed(0.8F);
                                SendTitleAboutSpeed(8, player, false);
                                break;
                            case 9:
                                player.setWalkSpeed(0.9F);
                                SendTitleAboutSpeed(9, player, false);
                                break;
                            case 10:
                                player.setWalkSpeed(1F);
                                SendTitleAboutSpeed(10, player, false);
                                break;
                            case 0:
                                player.setWalkSpeed(0F);
                                SendTitleAboutSpeed(0, player, false);
                                break;

                        }
                    }

                } else {
                    player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/speed < 1/10 >"));
                }
            } else {
                player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/speed < 1/10 >"));
            }
        }
        return false;
    }


    public void SendTitleAboutSpeed(int fl, Player player, boolean bolean) {
        if(bolean) {
            player.sendMessage(TextUtils.corolize("&7[ &e&lSPEED &7] &7Ustawiono latanie na &c" + fl));
        } else {
            player.sendMessage(TextUtils.corolize("&7[ &e&lSPEED &7] &7Ustawiono chodzenie na &c" + fl));
        }
    }
}

