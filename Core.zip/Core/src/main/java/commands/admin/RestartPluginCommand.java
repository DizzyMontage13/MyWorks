package commands.admin;

import Components.CaseFile;
import Components.DropFile;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RestartPluginCommand implements CommandExecutor {

    Main plugin;

    public RestartPluginCommand(Main main) {
        plugin = main;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;

            if(player.hasPermission("dizzycore.reload") || player.isOp()) {

                if(args.length == 1) {

                    String string = args[0];

                    if(string.equals("drop")) {
                        DropFile.saveDefaultConfig();
                        player.sendMessage(TextUtils.colorizeWithPrefix("&c&lPomyslnie przeladowano config &a&lDROPU"));
                    } else if (string.equals("config")) {
                        plugin.reloadConfig();
                        Main.getMain().reloadConfig();

                        player.sendMessage(TextUtils.colorizeWithPrefix("&c&lPomyslnie przeladowano config &e" + plugin.getDescription().getFullName()));
                    } else if(string.equals("case")) {
                        CaseFile.saveDefaultConfig();
                        CaseFile.reloadConfig();

                        player.sendMessage(TextUtils.colorizeWithPrefix("&c&lPomyslnie przeladowano config &a&lCASE"));
                    } else {
                        player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/przeladuj (config / drop / case)"));
                    }
                } else {
                    player.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/przeladuj (config / drop)"));
                }
            }

        } else {
            plugin.reloadConfig();
            Main.getMain().reloadConfig();
            Bukkit.getLogger().info("Przeladowano config pluginu");
        }
        return false;
    }

}
