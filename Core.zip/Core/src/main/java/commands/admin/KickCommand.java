package commands.admin;

import Utils.TextUtils;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;


public class KickCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {


            if(sender.hasPermission("dizzyCore.kick") || sender.isOp()) {
                if(args.length >= 2) {
                    Player user = Bukkit.getPlayer(args[0]);
                    StringBuilder stringBuilder = new StringBuilder();

                    for(int i = 1; i < args.length; i++) {
                        stringBuilder.append(args[i]).append(" ");
                    }

                    String string = stringBuilder.toString();

                    if(user != null && user.isOnline()) {
                            user.kickPlayer(TextUtils.corolize("&7&l» [ &c&lTWOJE IP &7] &7&l« " +
                                    "\n \n &fZostales &4wyrzocony &fz serwera \n" +
                                    " &fprzez : &e&l " + sender.getName() + " \n" +
                                    " &fpowod : &f " + string + " \n  \n" +
                                    "&7&l» [ &c&lTWOJE IP &7] &7&l«"));

                    } else {
                        sender.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                    }

                } else if (args.length == 1) {
                    Player user = Bukkit.getPlayer(args[0]);

                    if(user != null && user.isOnline()) {
                        user.kickPlayer(TextUtils.corolize("&7&l» [ &e&lSALK &f&lMC &7] &7&l« " +
                                "\n \n &fZostales &4wyrzocony &fz serwera \n" +
                                " &fprzez : &e&l " + sender.getName() + " \n \n" +
                                "&7&l» [ &e&lSALK &f&lMC &7] &7&l«"));
                    } else {
                        sender.sendMessage(TextUtils.Wrong("&7Nie ma takiego gracza &aONLINE"));
                    }

                } else {
                    sender.sendMessage(TextUtils.Wrong("&7Poprawne uzycie &f/kick <Gracz> (powod)"));
                }
            } else {
                sender.sendMessage(TextUtils.Wrong("&7Nie masz uprawnien do tej komendy!"));
            }


        return false;
    }
}
