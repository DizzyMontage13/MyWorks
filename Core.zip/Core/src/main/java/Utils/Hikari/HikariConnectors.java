package Utils.Hikari;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class HikariConnectors {
    private final HikariDataSource dataSource = new HikariDataSource(getConfig());

    public HikariConnectors() throws SQLException {
    }

    public HikariDataSource getDataSource() {
        return this.dataSource;
    }


    public final Connection connection = this.dataSource.getConnection();

    public Connection getConnection() {
        return this.connection;
    }

    private HikariConfig getConfig() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:mysql://localhost:3306/dizzycore");
        config.setUsername("root");
        config.setPassword("");
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        return config;
    }
}
