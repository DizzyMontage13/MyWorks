package Utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;

public class FarmerBlock {

    public static ItemStack getBoyFarmer(int amount) {

        return new ItemBuilder(Material.GRAY_GLAZED_TERRACOTTA).setAmount(amount).addLores(Arrays.asList(
                " ",
                TextUtils.corolize("&7&l» &fPostaw na ziemi, aby wypelnic bloki obsydianem"),
                TextUtils.corolize("&7&l» &c&lUWAGA &FPod generatorem musi być &apusto"),
                TextUtils.corolize("&7&l» &fJezeli &5&lBOYFARMER &fnapotka blok przestanie pracowac"),
                " "
        )).setTitle(TextUtils.corolize("&7» &5&lBOYFARMER &7«")).build();
    }

    public static ItemStack getSandFarmer(int amount) {

        return new ItemBuilder(Material.YELLOW_GLAZED_TERRACOTTA).setAmount(amount).addLores(Arrays.asList(
                " ",
                TextUtils.corolize("&7&l» &fPostaw na ziemi, aby wypelnic bloki piaskiem"),
                TextUtils.corolize("&7&l» &c&lUWAGA &fPod generatorem musi być &apusto"),
                TextUtils.corolize("&7&l» &fJezeli &e&lSANDFARMER &fnapotka blok przestanie pracowac"),
                " "
        )).setTitle(TextUtils.corolize("&7» &e&lSANDFARMER &7«")).build();

    }

    public static ItemStack getKopaczFosy(int amount) {

        return new ItemBuilder(Material.WHITE_GLAZED_TERRACOTTA).setAmount(amount).addLores(Arrays.asList(
                " ",
                TextUtils.corolize("&7&l» &fPostaw na ziemi, aby wypelnic bloki powietrzem"),
                " "
        )).setTitle(TextUtils.corolize("&7» &d&lKOPACZ FOSY &7«")).build();
    }
}
