package Utils;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;

import java.util.ArrayList;

public class AntNoggin {


    public static ItemStack getAntiLegs(int amount) {

       ArrayList<String> lists = new ArrayList<>();

        lists.add("");
        lists.add(TextUtils.corolize("&7&l» &fJeżeli trafiłeś w nogi ten przedmiot uratuje cie z nich"));
        lists.add(TextUtils.corolize("&7&l» &fKliknij a tepnie cie do &eOPRAWCY"));
        lists.add("");

        ItemStack boots = new ItemStack(Material.LEATHER_BOOTS, amount);
        LeatherArmorMeta meta4 = (LeatherArmorMeta) boots.getItemMeta();
        assert meta4 != null;
        meta4.setColor(Color.PURPLE);
        meta4.setDisplayName(TextUtils.corolize("&7» &2&lANTY NOGI &7«"));
        meta4.setLore(lists);
        boots.setItemMeta(meta4);


        return boots;

    }
}
