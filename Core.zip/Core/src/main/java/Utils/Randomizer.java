package Utils;

import java.util.Random;

public class Randomizer {


    public static int RandomInt() {
        Random random = new Random();

        return random.nextInt(101);
    }

    public static boolean getChance(double chance) {
        Random random = new Random();
        double random2 = random.nextDouble() * 100.0D;
        return (random2 <= chance);
    }

}
