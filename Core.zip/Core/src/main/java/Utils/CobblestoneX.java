package Utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;

public class CobblestoneX {

    public static ItemStack getCobbleX(int amount) {

        return new ItemBuilder(Material.MOSSY_COBBLESTONE).setTitle(TextUtils.corolize("&7» &7&lCOBBLE&a&lX &7«"))
                .addLores(Arrays.asList (
                        "",
                        TextUtils.corolize("&7&l» &fPostaw na ziemi, zeby otworzyc"),
                        TextUtils.corolize("&7&l» &fWylatuja z niej itemy które znajdziesz pod /drop")
                )).setAmount(amount).build();
    }
}
