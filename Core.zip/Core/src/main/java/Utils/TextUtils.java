package Utils;

import Components.CaseFile;
import net.minecraft.network.PacketDataSerializer;
import net.minecraft.network.chat.IChatBaseComponent;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.PacketPlayOutChat;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_17_R1.entity.CraftPlayer;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

public class TextUtils {

    public static String corolize(String PaintContent) {
        return ChatColor.translateAlternateColorCodes('&', PaintContent);
    }

    public static String colorizeWithPrefix(String content) {
        return corolize("&7&l[ &e&lSALK&f&lMC.PL &7&l] &r" + content);
    }


    public static String Wrong(String content) {
        return corolize("&c&lBlad! &r" + content);
    }


    public static boolean isInteger(String string) {
        return Pattern.matches("-?[0-9]+", string.subSequence(0, string.length()));
    }

    public static void broadcast(String message) {
        Bukkit.broadcastMessage(corolize(message));
    }

    public static void sendHoverMessage(CommandSender p, String s1, String s2) {
        IChatBaseComponent msg = IChatBaseComponent.ChatSerializer.a(corolize("{\"text\":\"" + s1 + "\",\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\"" + s2 + "\"}]}},\"clickEvent\":{\"action\":\"suggest_command\",\"value\":\"\"}}"));
        PacketPlayOutChat hover = new PacketPlayOutChat((PacketDataSerializer) msg);
        (((CraftPlayer)p).getHandle()).b.sendPacket((Packet)hover);
    }

    public static void DropItem(Material material, Block block, Location location) {
        block.getWorld().dropItemNaturally(location, new ItemStack(material));
    }

    public static ItemStack getItemStackFromString(String itemstack) {
        String[] splits = itemstack.split("@");
        String type = splits[0];
        String data = (splits.length == 2) ? splits[1] : null;
        if (data == null)
            return new ItemStack(Material.getMaterial(type), 1);
        return new ItemStack(Material.getMaterial(type), (short)Integer.parseInt(data));
    }


    
    public static HashMap<Enchantment, Integer> getEnchantments(String string) {
        List<String> list = CaseFile.getConfig().getStringList("case." + string + ".enchantments");

        for (String enchantment : list) {
            String[] kekw = enchantment.split(":");
            Enchantment ench = Enchantment.getByName(kekw[0]);
            int lvl = Integer.parseInt(kekw[1]);

            HashMap<Enchantment, Integer> maps = null;
            assert false;
            maps.put(ench, lvl);

            return maps;
        }
        
        return null;
    }
}
