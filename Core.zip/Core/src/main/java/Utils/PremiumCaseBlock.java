package Utils;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class PremiumCaseBlock {





    public static ItemStack getPremiumCases(int amount) {

        return new ItemBuilder(Material.BARREL).setAmount(amount).addLores(Arrays.asList(
            TextUtils.corolize("&7&l» &fPostaw na ziemi, zeby otworzyc"),
            TextUtils.corolize("&7&l» &fWylatuja z niej cenne itemy")
        )).setTitle(TextUtils.corolize("&7» &5&lMYSTERY BARREL &7«")).addEnchantment(Enchantment.DURABILITY, 10).build();
    }
}
