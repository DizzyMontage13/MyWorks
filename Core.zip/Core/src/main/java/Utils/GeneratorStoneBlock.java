package Utils;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;

public class GeneratorStoneBlock {

    public static ItemStack getGeneratorStoneBlock(int amount) {

        return new ItemBuilder(Material.HONEYCOMB_BLOCK).setAmount(amount).addLores(Arrays.asList(
                " ",
                TextUtils.corolize("&7&l» &fPostaw na ziemi, zeby stworzyć generator"),
                TextUtils.corolize("&7&l» &fStone generuje sie co &e1.5 &fsekundy"),
                " ",
                TextUtils.corolize("&7&l» &fStoniarke zniszczysz &e&lZLOTYM KILOFEM")
        )).setTitle(TextUtils.corolize("&7» &6&lSTONIARKA &7«")).build();
    }
}
