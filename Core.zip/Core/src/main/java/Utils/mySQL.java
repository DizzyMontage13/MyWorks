package Utils;

import Components.User;
import Utils.Hikari.HikariConnectors;
import com.Challangerson.Main;

import java.sql.*;
import java.util.List;

public class mySQL {

    private Connection connection;


    private HikariConnectors hikariConnector;

    public mySQL() {
        try {
            this.hikariConnector = new HikariConnectors();
            this.connection = this.hikariConnector.getConnection();
        } catch (SQLException troubles) {
            troubles.printStackTrace();
        }
    }

    public void connect() {
        try {
            this.connection.prepareStatement("CREATE TABLE IF NOT EXISTS KITS (UUID VARCHAR(255), KIT_GRACZ BIGINT(20), KIT_VIP BIGINT(20), KIT_MIESO BIGINT(20))").executeUpdate();
            this.connection.prepareStatement("CREATE TABLE IF NOT EXISTS HOMES (UUID VARCHAR(255)").executeUpdate();
        } catch (SQLException troubles) {
            troubles.printStackTrace();
        }
    }


    public void shutdown() {
        try {
            this.connection.close();
            this.hikariConnector.getDataSource().close();
        } catch (SQLException troubles) {
            troubles.printStackTrace();
        }
    }

    public void loadUsers() {
        try {
            List<User> getUsers = Main.getMain().getUserManager().getUsers();
            Statement statement = this.connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM KITS");

            while (resultSet.next()) {
                String uuid = resultSet.getString("UUID");
                long kit_gracz = resultSet.getLong("KIT_GRACZ");
                long kit_vip = resultSet.getLong("KIT_VIP");
                long kit_mieso = resultSet.getLong("KIT_MIESO");

                User user = new User(uuid, kit_gracz, kit_vip, kit_mieso);
                getUsers.add(user);
            }

            statement.close();
            resultSet.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void update(String request) {
        try {
            PreparedStatement preparedStatement = this.connection.prepareStatement(request);

            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
    }

    public ResultSet updaters(String request) {
        try {
            PreparedStatement statement = connection.prepareStatement(request);

            return statement.executeQuery();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return null;
    }


}


//    private final HikariDataSource dataSource;
//    private static MySQL instance;
//
//
//    private final Connection connection;
//
//
//    private final HikariConnector hikariConnector;
//
//    public MySQL() {
//        try {
//            this.hikariConnector = new HikariConnector();
//            this.connection = this.hikariConnector.getConnection();
//        } catch (Throwable $ex) {
//            throw $ex;
//        }
//    }
//
//    public void shutdown() {
//        try {
//            this.connection.close();
//            this.hikariConnector.getDataSource().close();
//        } catch (Throwable $ex) {
//            throw $ex;
//        }
//
//    public MySQL()
//    {
//        instance = this;
//
//
//        this.dataSource = new HikariDataSource();
//        this.dataSource.setMaximumPoolSize(21);
//        this.dataSource.setJdbcUrl("jdbc:mysql://localhost:3306/dizzycore");
//        this.dataSource.setUsername("root");
//        this.dataSource.setPassword("");
//        this.dataSource.addDataSourceProperty("cachePrepStmts", "true");
//        this.dataSource.addDataSourceProperty("prepStmtCacheSize", "250");
//        this.dataSource.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
//        this.dataSource.addDataSourceProperty("useServerPrepStmts", "true");
//    }
//
//    public void update(String request) {
//        try(Connection con = MySQL.getConnection()) {
//
//            PreparedStatement preparedStatement = con.prepareStatement(request);
//
//            preparedStatement.executeUpdate();
//
//        } catch (SQLException throwable) {
//            throwable.printStackTrace();
//        }
//    }
//
//    public ResultSet updaters(String request) {
//        try (Connection con = MySQL.getConnection()) {
//            PreparedStatement statement = con.prepareStatement(request);
//
//            return statement.executeQuery();
//        }
//        catch (SQLException sqlException) {
//            sqlException.printStackTrace();
//        }
//
//        return null;
//    }
//
//    private HikariDataSource getDataSource() { return dataSource; }
//
//    public void shutdown() { this.dataSource.close(); }
//
//    public static Connection getConnection() throws SQLException { return getInstance().getDataSource().getConnection(); }
//
//    public static MySQL getInstance() {
//        if(instance == null) {
//            return new MySQL();
//        }
//        return instance;
//    }

