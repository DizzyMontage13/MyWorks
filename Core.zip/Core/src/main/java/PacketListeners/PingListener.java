package PacketListeners;


import Utils.TextUtils;
import com.Challangerson.Main;
import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.events.PacketListener;
import com.comphenix.protocol.wrappers.WrappedGameProfile;
import com.comphenix.protocol.wrappers.WrappedServerPing;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.spigotmc.SpigotConfig;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PingListener implements Listener {


    private static final FileConfiguration main = Main.getMain().getConfig();

    private static String formatText(String text) {
        String realslots = "" + Bukkit.getServer().getMaxPlayers();
        String realonline = "" + Bukkit.getServer().getOnlinePlayers().size();
        String fakeslots = "" +  10;
        String fakeonline = "" + 15;
        String Formatted = TextUtils.corolize(text).replace("%realslots%", realslots).replace("%realonline%", realonline).replace("%fakeonline%", fakeonline).replace("%fakeslots%", fakeslots);


        return Formatted;
    }


    public static void activateVersionText(WrappedServerPing ping) {
        ping.setVersionProtocol(-1);
        ping.setVersionName(formatText(main.getString("Motd.LeftMOTD")));
    }

    public static void activateHoverText(WrappedServerPing ping) {
        List<WrappedGameProfile> players = new ArrayList<>();
        for (String string : main.getStringList("Motd.HoverText"))
            players.add(new WrappedGameProfile(UUID.randomUUID(), TextUtils.corolize(string)));
        ping.setPlayers(players);
    }

}
