package PacketListeners;

import com.Challangerson.Main;
import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.events.PacketListener;
import com.comphenix.protocol.wrappers.WrappedServerPing;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public class ProtocalLibImplementation {

    private static Main main;

    public ProtocalLibImplementation(Main plugin) {
        setPlugin(plugin);
    }

    private static void setPlugin(Main plugin) {
        main = plugin;
    }

    public void setupIntegration() {
        Bukkit.getLogger().info("zaladowano hover motd.");
        ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(
                PacketAdapter.params(main, PacketType.Status.Server.SERVER_INFO).optionAsync()) {
            public void onPacketSending(PacketEvent event) {
                WrappedServerPing ping = event.getPacket().getServerPings().read(0);
                PingListener.activateHoverText(ping);
                PingListener.activateVersionText(ping);
            }

        });
    }
}
