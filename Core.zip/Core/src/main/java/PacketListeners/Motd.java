package PacketListeners;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerListPingEvent;

import java.io.File;

public class Motd implements Listener {

    Main plugin;


    public Motd(Main main) {
        plugin = main;
    }

    @EventHandler
    public void onServerPing(ServerListPingEvent event) throws Exception {
        String motorists = TextUtils.corolize("&7&l» &fJedyny taki serwer &eMEDIUMHC &7w &c&lPOLSCE!");
        String microsecond = TextUtils.corolize("&7&l» &fStart juz w ten &a&lPIATEK");

        File file = new File("plugins/Main/lobby.png");

        event.setMotd(motorists + "\n" + microsecond);
        event.setMaxPlayers(100);
        

        event.setServerIcon(Bukkit.loadServerIcon(file));
    }
}

