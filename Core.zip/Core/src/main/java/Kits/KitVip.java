package Kits;

import Components.User;
import Components.UserManager;
import Utils.ItemBuilder;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Calendar;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class KitVip {





    public static ItemStack[] GetKitVip() {
        ItemStack sword = new ItemBuilder(Material.IRON_SWORD).addEnchantment(Enchantment.DAMAGE_ALL, 4).addEnchantment(Enchantment.DURABILITY, 2).addEnchantment(Enchantment.FIRE_ASPECT, 1).build();
        ItemStack helm =  new ItemBuilder(Material.IRON_HELMET).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3).addEnchantment(Enchantment.DURABILITY, 2).build();
        ItemStack klata =  new ItemBuilder(Material.IRON_CHESTPLATE).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3).addEnchantment(Enchantment.DURABILITY, 2).build();
        ItemStack spodnie =  new ItemBuilder(Material.IRON_LEGGINGS).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3).addEnchantment(Enchantment.DURABILITY, 2).build();
        ItemStack buty =  new ItemBuilder(Material.IRON_BOOTS).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3).addEnchantment(Enchantment.DURABILITY, 2).build();
        ItemStack kilof =  new ItemBuilder(Material.DIAMOND_PICKAXE).addEnchantment(Enchantment.DIG_SPEED, 4).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.LOOT_BONUS_BLOCKS, 3).build();
        ItemStack tarcza = new ItemBuilder(Material.SHIELD).addEnchantment(Enchantment.DURABILITY, 2).build();
        ItemStack jablka =  new ItemBuilder(Material.GOLDEN_APPLE).setAmount(3).build();
        ItemStack jedzenie = new ItemBuilder(Material.PUMPKIN_PIE).setAmount(16).build();
        ItemStack perly = new ItemBuilder(Material.ENDER_PEARL).setAmount(2).build();
        ItemStack luk = new ItemBuilder(Material.BOW).addEnchantment(Enchantment.ARROW_DAMAGE, 4).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.ARROW_INFINITE, 1).build();
        ItemStack strzala =  new ItemBuilder(Material.ARROW).build();

        return new ItemStack[] {sword, helm, klata, spodnie, buty, kilof, tarcza, jablka, jedzenie, perly, luk, strzala};
    }

    public static void getKitVip(Player player) {

        for( int i = 0; i < GetKitVip().length; i ++) {
            player.getInventory().addItem(GetKitVip()[i]);
        }

    }


    public void CheckKitVip(Player player) {

        Long time = System.currentTimeMillis() + TimeUnit.HOURS.toMillis(12);

        User u;

        if(player.hasPermission("dizzycore.kit.vip")) {

            if(player.isOp()) {

                getKitVip(player);
                player.sendMessage(TextUtils.corolize("&a&lSukces! &7Odebrales Kit VIP"));

            } else {

                UUID uuid = player.getUniqueId();

                u = Main.getMain().getUserManager().getUser(uuid.toString());

                if(u == null) { System.out.println("OGOLNIE CHUJOZA"); return; }

                if (Main.getMain().getUserManager().ifUserExist(uuid) && u.ifkit_vip_exists()) {
                    if (System.currentTimeMillis() > u.getKit_vip()) {

                        getKitVip(player);
                        player.sendMessage(TextUtils.corolize("&a&lSukces! &7Odebrales Kit VIPa"));
                        u.setkit_vip(time);
                        u.UpdateSQL();
                    } else {


                        Calendar calendar = Calendar.getInstance();

                        long timeline = (u.getKit_vip() - System.currentTimeMillis());

                        calendar.setTimeInMillis(timeline);

                        int hours = calendar.get(Calendar.HOUR);
                        int minutes = calendar.get(Calendar.MINUTE);


                        player.sendMessage(TextUtils.Wrong("&7Aktualnie kit jeszcze jest nie dostepny. Następny raz " +
                                "będziesz mógł odebrać go za : &e" + hours + " godz i " + minutes + " minut"));
                    }
                } else {
                    getKitVip(player);
                    player.sendMessage(TextUtils.corolize("&a&lSukces! &7Odebrales Kit VIPs"));
                    u.setkit_vip(time);
                    u.UpdateSQL();

                }
            }
        } else {
            player.sendMessage(TextUtils.Wrong("&7Nie masz uprawnien aby odebrac tego kita"));
        }
    }

    public String accesForKit(Player player) {
        User u;

        String yes = TextUtils.corolize("&a&l✔");
        String no = TextUtils.corolize("&c&l✘");

        UUID uuid = player.getUniqueId();


        if(player.isOp()) return yes;

        if(!player.hasPermission("dizzycore.kit.vip")) return no;

        u = Main.getMain().getUserManager().getUser(uuid.toString());

        if(u == null) { System.out.println("OGOLNIE CHUJOZA"); return no; }

        if((System.currentTimeMillis() > u.getKit_vip())) return yes;

        if(!u.ifkit_vip_exists()) return yes;

        return no;
    }


}
