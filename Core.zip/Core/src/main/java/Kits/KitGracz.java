package Kits;

import Components.User;
import Components.UserManager;
import Utils.ItemBuilder;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Calendar;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class KitGracz {




    public static ItemStack[] GetKitGracz() {


        ItemStack miecz = new ItemBuilder(Material.STONE_SWORD).build();
        ItemStack klata = new ItemBuilder(Material.LEATHER_CHESTPLATE).build();
        ItemStack jedzenie = new ItemBuilder(Material.PUMPKIN_PIE).setAmount(16).build();
        ItemStack kilof = new ItemBuilder(Material.IRON_PICKAXE).addEnchantment(Enchantment.DIG_SPEED, 3).addEnchantment(Enchantment.DURABILITY, 2).build();
        ItemStack pochodnie = new ItemBuilder(Material.TORCH).setAmount(16).build();
        ItemStack enderchest = new ItemBuilder(Material.ENDER_CHEST).build();
        

        return new ItemStack[] { miecz, klata, jedzenie, kilof, pochodnie, enderchest};
    }

    public static void getKitGracz(Player player) {
        for(int i =0; i < GetKitGracz().length; i ++) {

            player.getInventory().addItem(GetKitGracz()[i]);
        }
    }

    public void CheckKitGracz(Player player) {
            User u;

            long time = System.currentTimeMillis() + TimeUnit.HOURS.toMillis(1);

            UUID uuid = player.getUniqueId();


            if(player.isOp()) {

                getKitGracz(player);
                player.sendMessage(TextUtils.corolize("&a&lSukces! &7Odebrales kit gracz'a"));

            } else {



                u = Main.getMain().getUserManager().getUser(uuid.toString());
                if(u == null) { System.out.println("OGOLNIE CHUJOZA"); return; }

                if (Main.getMain().getUserManager().ifUserExist(uuid) && u.ifkit_gracz_exists()) {
                    if (System.currentTimeMillis() > u.getKit_gracz()) {

                        getKitGracz(player);

                        u.setKit_gracz(time);
                        u.UpdateSQL();
                        player.sendMessage(TextUtils.corolize("&a&lSukces! &7Odebrales kit gracz'a"));
                    } else {


                        Calendar calendar = Calendar.getInstance();
                        long timeline = (u.getKit_gracz() - System.currentTimeMillis());

                        calendar.setTimeInMillis(timeline);

                        int minutes = calendar.get(Calendar.MINUTE);


                        player.sendMessage(TextUtils.Wrong("&7Aktualnie kit jest jeszcze nie dostepny. Następny raz " +
                                "będziesz mógł odebrać go za : &e" +  minutes + " minut"));
                    }
                } else {
                    getKitGracz(player);
                    player.sendMessage(TextUtils.corolize("&a&lSukces! &7Odebrales kit gracz'a"));
                    u.setKit_gracz(time);
                    u.UpdateSQL();
                }
            }
    }

    public String accesForKit(Player player) {
        User u;


        String yes = TextUtils.corolize("&a&l✔");
        String no = TextUtils.corolize("&c&l✘");

        UUID uuid = player.getUniqueId();

        if(player.isOp()) return yes;
        u = Main.getMain().getUserManager().getUser(uuid.toString());

        if(u == null) { System.out.println("OGOLNIE CHUJOZASA"); return no; }

        if((System.currentTimeMillis() > u.getKit_gracz())) return yes;

        if(Main.getMain().getUserManager().ifUserExist(uuid) && u.ifkit_gracz_exists()) return no;

        return no;
    }


}
