package Inventories;

import Utils.ItemBuilder;
import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.PolarBear;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.Potion;
import org.bukkit.potion.PotionType;

import java.util.Arrays;

public class DropGui {

    public static Inventory drop;
    public static Inventory premiumcase;

    public static void DropInventory(Player player) {
        drop = Bukkit.createInventory(null, 3*9, TextUtils.corolize("&7» &c&lDROP &7«"));

        for ( int i = 0; i < 3*9; i++) {
            drop.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        drop.setItem(10, new ItemBuilder(Material.BARREL).setTitle(TextUtils.corolize("&7&l» &5&lMYSTERY BARREL &7&l«")).
                addLores(Arrays.asList (
                        TextUtils.corolize(" "),
                        TextUtils.corolize("&7&l» &7Kliknij Aby sprawdzic co dropi z &5&lMYSTERY BARREL"),
                        " ",
                        TextUtils.corolize("&7&l» &5&lMYSTERY BARREL &7&l«")
                )).addEnchantment(Enchantment.DURABILITY, 10).build());

        drop.setItem(13, new ItemBuilder(Material.STONE).setTitle(TextUtils.corolize("&7&l» &a&lDROP ZE STONE &7&l«")).
                addLores(Arrays.asList (
                        TextUtils.corolize(" "),
                        TextUtils.corolize("&7&l» &7Kliknij Aby sprawdzic co dropi z &a&lSTONE"),
                        " ",
                        TextUtils.corolize("&7&l» &a&lDROP ZE STONE &7&l«")
                )).build());

        drop.setItem(16, new ItemBuilder(Material.TRIPWIRE_HOOK).setTitle(TextUtils.corolize("&7&l» &7&lDROP ZE &e&lSKRZYN &7&l«")).
                addLores(Arrays.asList (
                        TextUtils.corolize(" "),
                        TextUtils.corolize("&7&l» &7Kliknij Aby sprawdzic co dropi z &e&lSKRZYN"),
                        " ",
                        TextUtils.corolize("&7&l» &7&lDROP ZE &e&lSKRZYN &7&l«")
                )).build());

        player.openInventory(drop);

        }

        public static void PremiumCaseGui(Player player) {
            premiumcase = Bukkit.createInventory(null, 6*9, TextUtils.corolize("&7» &6&lPREMIUMCASE &7«"));

            for (int i = 0; i < 2*9; i++) {
                premiumcase.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
            }

            for (int i = 1; i <= 3; i++) {
                premiumcase.setItem(i, new ItemBuilder(Material.RED_STAINED_GLASS_PANE).setTitle(TextUtils.corolize("&c&lWYLACZ POWIADOMIENIA")).addLores(Arrays.asList(
                        TextUtils.corolize("&7&l» &fKliknij aby &cwylaczyc &fpowiadomienia o dropach z &5Magicznych Baryłek ")
                )).build());
            }

            for (int i = 5; i <= 7; i++) {
                premiumcase.setItem(i, new ItemBuilder(Material.GREEN_STAINED_GLASS_PANE).setTitle(TextUtils.corolize("&a&lWLACZ POWIADOMIENIA")).addLores(Arrays.asList(
                        TextUtils.corolize("&7&l» &fKliknij aby &awlaczyc &fpowiadomienia o dropach z &5Magicznych Baryłek ")
                )).build());
            }

            for (int i = 0; i < 54; i += 9) {
                premiumcase.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
            }

            for (int i = 8; i < 54; i += 9) {
                premiumcase.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
            }

            premiumcase.setItem(19, new ItemBuilder(Material.DIAMOND_HELMET).setTitle(TextUtils.corolize("&7&l» &9&lDIAX HELM &7&l«")).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build());
            premiumcase.setItem(20, new ItemBuilder(Material.DIAMOND_CHESTPLATE).setTitle(TextUtils.corolize("&7&l» &9&lDIAX KLATA &7&l«")).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build());
            premiumcase.setItem(21, new ItemBuilder(Material.DIAMOND_LEGGINGS).setTitle(TextUtils.corolize("&7&l» &9&lDIAX SPODNIE &7&l«")).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build());
            premiumcase.setItem(22, new ItemBuilder(Material.DIAMOND_BOOTS).setTitle(TextUtils.corolize("&7&l» &9&lDIAX BUTY &7&l«")).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 4).build());
            premiumcase.setItem(23, new ItemBuilder(Material.DIAMOND_SWORD).setTitle(TextUtils.corolize("&7&l» &9&lDIAX MIECZ &7&l«")).addEnchantment(Enchantment.FIRE_ASPECT, 2).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.DAMAGE_ALL, 5).build());
            premiumcase.setItem(24, new ItemBuilder(Material.DIAMOND_SWORD).setTitle(TextUtils.corolize("&7&l» &9&lDIAX MIECZ &7&l«")).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.KNOCKBACK, 2).build());
            premiumcase.setItem(25, new ItemBuilder(Material.BOW).setTitle(TextUtils.corolize("&7&l» &e&lLUK &7&l«")).addEnchantment(Enchantment.ARROW_DAMAGE, 5).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.ARROW_FIRE, 1).addEnchantment(Enchantment.ARROW_INFINITE, 1).build());
            premiumcase.setItem(28, new ItemBuilder(Material.BOW).setTitle(TextUtils.corolize("&7&l» &e&lLUK &7&l«")).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.ARROW_KNOCKBACK, 2).addEnchantment(Enchantment.ARROW_INFINITE, 1).build());
            premiumcase.setItem(29, new ItemBuilder(Material.ARROW).setTitle(TextUtils.corolize("&7&l» &7&lSTRZALY &7&l«")).setAmount(16).build());
            premiumcase.setItem(30, new ItemBuilder(Material.GOLD_INGOT).setTitle(TextUtils.corolize("&7&l» &6&lZLOTO &7&l«")).setAmount(16).build());
            premiumcase.setItem(31, new ItemBuilder(Material.DIAMOND).setTitle(TextUtils.corolize("&7&l» &9&lDIAMENTY &7&l«")).setAmount(16).build());
            premiumcase.setItem(32, new ItemBuilder(Material.IRON_INGOT).setTitle(TextUtils.corolize("&7&l» &7&lZELAZO &7&l«")).setAmount(16).build());
            premiumcase.setItem(33, new ItemBuilder(Material.EMERALD).setTitle(TextUtils.corolize("&7&l» &a&lEMERALDY &7&l«")).setAmount(16).build());
            premiumcase.setItem(34, new ItemBuilder(Material.POTION).setTitle(TextUtils.corolize("&7&l» &c&lSTRENGTH &7&l«")).setPotion(new Potion(PotionType.STRENGTH,1)).build());
            premiumcase.setItem(37, new ItemBuilder(Material.ENCHANTED_BOOK).setTitle(TextUtils.corolize("&7&l» &7&lMENDING &7&l«")).addEnchantment(Enchantment.MENDING, 1).build());
            premiumcase.setItem(38, new ItemBuilder(Material.BLAZE_ROD).setTitle(TextUtils.corolize("&7&l» &6&lBLAZE RODY &7&l«")).setAmount(4).build());
            premiumcase.setItem(39, new ItemBuilder(Material.MOSSY_COBBLESTONE).setTitle(TextUtils.corolize("&7&l» &a&lCOBBLE&7&lX &7&l«")).setAmount(8).build());
            premiumcase.setItem(40, new ItemBuilder(Material.SHULKER_BOX).setTitle(TextUtils.corolize("&7&l» &5&lSHULKER BOX &7&l«")).build());
            premiumcase.setItem(41, new ItemBuilder(Material.NETHERITE_INGOT).setTitle(TextUtils.corolize("&7&l» &8&lNETHERITE &7&l«")).setAmount(4).build());
            premiumcase.setItem(42, new ItemBuilder(Material.WITHER_SKELETON_SKULL).setTitle(TextUtils.corolize("&7&l» &8&lGLOWA CZARNEGO SZKIELETA &7&l«")).build());
            premiumcase.setItem(43, new ItemBuilder(Material.POTION).setTitle(TextUtils.corolize("&7&l» &e&lSPEED &7&l«")).setPotion(new Potion(PotionType.SPEED, 1)).build());

            for(int i = 45; i < 54; i++) {
                premiumcase.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
            }




            player.openInventory(premiumcase);

        }
}



