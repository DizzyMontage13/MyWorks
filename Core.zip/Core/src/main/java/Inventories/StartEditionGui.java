package Inventories;

import Utils.ItemBuilder;
import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;

import java.util.Arrays;

public class StartEditionGui {

    public static Inventory editionstart;


    public static Inventory Guieditionstart() {

        editionstart = Bukkit.createInventory(null, 3*9, TextUtils.corolize("&7» &c&lADMINPANEL &7«"));

        for(int i = 0; i < 27; i++) {
            editionstart.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        editionstart.setItem(10, new ItemBuilder(Material.CRAFTING_TABLE).setTitle(TextUtils.corolize("&7» &b&lDIAX SETY &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &fMożliwość włączenia diamentowych setów"),
                " ",
                TextUtils.corolize("&7» &b&lDIAX SETY &7«")
        )).build());

        editionstart.setItem(11, new ItemBuilder(Material.END_CRYSTAL).setTitle(TextUtils.corolize("&7» &c&lGILDIE &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &fMożliwość włączenia tworzenia gildii"),
                " ",
                TextUtils.corolize("&7» &c&lGILDIE &7«")
        )).build());

        editionstart.setItem(12, new ItemBuilder(Material.ENCHANTING_TABLE).setTitle(TextUtils.corolize("&7» &e&lENCHANTOWANIE &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &fMożliwość włączenia enchantowania"),
                " ",
                TextUtils.corolize("&7» &e&lENCHANTOWANIE &7«")
        )).build());

        editionstart.setItem(13, new ItemBuilder(Material.NETHERITE_SWORD).setTitle(TextUtils.corolize("&7» &a&lKITY &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &fMożliwość odebrania kitów"),
                " ",
                TextUtils.corolize("&7» &a&lKITY &7«")
        )).build());


        editionstart.setItem(14, new ItemBuilder(Material.EMERALD).setTitle(TextUtils.corolize("&7» &2&lEFEKTY &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &fMożliwość włączenia efektów"),
                " ",
                TextUtils.corolize("&7» &2&lEFEKTY &7«")
        )).build());

        editionstart.setItem(26, new ItemBuilder(Material.BARRIER).setTitle(TextUtils.corolize("&7» &c&lPOWRÓT &7«")).build());


        return editionstart;
    }
}
