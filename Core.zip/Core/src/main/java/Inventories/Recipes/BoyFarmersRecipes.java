package Inventories.Recipes;

import Utils.*;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.Arrays;

public class BoyFarmersRecipes {

    public static Inventory SandFarmer;
    public static Inventory BoyFarmer;
    public static Inventory DiggerFossa;


    public static Inventory OpenSandFarmer(Player player) {

        SandFarmer = Bukkit.createInventory(null, 6 * 9, TextUtils.corolize("&7» &e&lSANDFARMER &f&lCRAFTING &7«"));

        for (int i = 0; i < 6 * 9; i++) {
            SandFarmer.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        SandFarmer.setItem(10, new ItemBuilder(Material.SAND).build());
        SandFarmer.setItem(11, new ItemBuilder(Material.GOLD_INGOT).build());
        SandFarmer.setItem(12, new ItemBuilder(Material.SAND).build());

        SandFarmer.setItem(19, new ItemBuilder(Material.REDSTONE).build());
        SandFarmer.setItem(20, new ItemBuilder(Material.LAVA_BUCKET).build());
        SandFarmer.setItem(21, new ItemBuilder(Material.REDSTONE).build());

        SandFarmer.setItem(28, new ItemBuilder(Material.SAND).build());
        SandFarmer.setItem(29, new ItemBuilder(Material.GOLD_INGOT).build());
        SandFarmer.setItem(30, new ItemBuilder(Material.SAND).build());

        SandFarmer.setItem(23, new ItemStackBuilder(Material.PLAYER_HEAD).setHead("CHEATINGEGIRL").setDisplayName(" ").build());

        SandFarmer.setItem(25, FarmerBlock.getSandFarmer(1));
        SandFarmer.setItem(34, new ItemBuilder(Material.CRAFTING_TABLE).setTitle(TextUtils.corolize("&7» &e&lAUTO CRAFTING &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &fPotrzebne itemy :"),
                TextUtils.corolize("&7» &f1x &clava"),
                TextUtils.corolize("&7» &f4x &episaku"),
                TextUtils.corolize("&7» &f2x &ezłota"),
                TextUtils.corolize("&7» &f2x &credstona"),
                " "
        )).build());

        SandFarmer.setItem(49, new ItemBuilder(Material.BARRIER).setTitle(TextUtils.corolize("&c&lPOWROT")).build());

        return SandFarmer;
    }

    public static Inventory OpenDiggerFossa(Player player) {

        DiggerFossa = Bukkit.createInventory(null, 6 * 9, TextUtils.corolize("&7» &d&lKOPACZFOSY &f&lCRAFTING &7«"));

        for (int i = 0; i < 6 * 9; i++) {
            DiggerFossa.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        DiggerFossa.setItem(10, new ItemBuilder(Material.STONE).build());
        DiggerFossa.setItem(11, new ItemBuilder(Material.EMERALD).build());
        DiggerFossa.setItem(12, new ItemBuilder(Material.STONE).build());

        DiggerFossa.setItem(19, new ItemBuilder(Material.EMERALD).build());
        DiggerFossa.setItem(20, new ItemBuilder(Material.DIAMOND_PICKAXE).build());
        DiggerFossa.setItem(21, new ItemBuilder(Material.EMERALD).build());

        DiggerFossa.setItem(28, new ItemBuilder(Material.STONE).build());
        DiggerFossa.setItem(29, new ItemBuilder(Material.EMERALD).build());
        DiggerFossa.setItem(30, new ItemBuilder(Material.STONE).build());

        DiggerFossa.setItem(23, new ItemStackBuilder(Material.PLAYER_HEAD).setHead("CHEATINGEGIRL").setDisplayName(" ").build());

        DiggerFossa.setItem(25, FarmerBlock.getKopaczFosy(1));
        DiggerFossa.setItem(34, new ItemBuilder(Material.CRAFTING_TABLE).setTitle(TextUtils.corolize("&7» &e&lAUTO CRAFTING &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &fPotrzebne itemy :"),
                TextUtils.corolize("&7» &f1x &bDiamentowy kilof"),
                TextUtils.corolize("&7» &f4x &aemeraldów"),
                TextUtils.corolize("&7» &f4x &8stona"),
                " "
        )).build());

        DiggerFossa.setItem(49, new ItemBuilder(Material.BARRIER).setTitle(TextUtils.corolize("&c&lPOWROT")).build());

        return DiggerFossa;
    }

    public static Inventory OpenBoyFarmer(Player player) {

        BoyFarmer = Bukkit.createInventory(null, 6 * 9, TextUtils.corolize("&7» &5&lBOYFARMER &f&lCRAFTING &7«"));

        for (int i = 0; i < 6 * 9; i++) {
            BoyFarmer.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        BoyFarmer.setItem(10, new ItemBuilder(Material.OBSIDIAN).build());
        BoyFarmer.setItem(11, new ItemBuilder(Material.DIAMOND).build());
        BoyFarmer.setItem(12, new ItemBuilder(Material.OBSIDIAN).build());

        BoyFarmer.setItem(19, new ItemBuilder(Material.REDSTONE).build());
        BoyFarmer.setItem(20, new ItemBuilder(Material.LAVA_BUCKET).build());
        BoyFarmer.setItem(21, new ItemBuilder(Material.REDSTONE).build());

        BoyFarmer.setItem(28, new ItemBuilder(Material.OBSIDIAN).build());
        BoyFarmer.setItem(29, new ItemBuilder(Material.DIAMOND).build());
        BoyFarmer.setItem(30, new ItemBuilder(Material.OBSIDIAN).build());

        BoyFarmer.setItem(23, new ItemStackBuilder(Material.PLAYER_HEAD).setHead("CHEATINGEGIRL").setDisplayName(" ").build());

        BoyFarmer.setItem(25, FarmerBlock.getBoyFarmer(1));
        BoyFarmer.setItem(34, new ItemBuilder(Material.CRAFTING_TABLE).setTitle(TextUtils.corolize("&7» &e&lAUTO CRAFTING &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &fPotrzebne itemy :"),
                TextUtils.corolize("&7» &f1x &clava"),
                TextUtils.corolize("&7» &f4x &8obsydianu"),
                TextUtils.corolize("&7» &f2x &bdiamentów"),
                TextUtils.corolize("&7» &f2x &credstona"),
                " "
        )).build());

        BoyFarmer.setItem(49, new ItemBuilder(Material.BARRIER).setTitle(TextUtils.corolize("&c&lPOWROT")).build());

        return BoyFarmer;
    }
}
