package Inventories.Recipes;

import Utils.*;
import org.bukkit.Bukkit;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;

public class Craftings {

    public static Inventory Craftings;

    public static Inventory OpenCraftings(Player player) {


        ItemStack bboots = new ItemStack(Material.LEATHER_BOOTS);
        LeatherArmorMeta meta4 = (LeatherArmorMeta) bboots.getItemMeta();
        assert meta4 != null;
        meta4.setColor(Color.BLUE);
        meta4.setDisplayName(TextUtils.corolize("&7» &2&lANTY NOGI &7«"));
        bboots.setItemMeta(meta4);

        Craftings = Bukkit.createInventory(null, 3 * 9, TextUtils.corolize("&7» &6&lCRAFTINGI &7«"));


        for (int i = 0; i < 3 * 9; i++) {
            Craftings.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        Craftings.setItem(10, FarmerBlock.getBoyFarmer(1));
        Craftings.setItem(11, FarmerBlock.getSandFarmer(1));
        Craftings.setItem(12, FarmerBlock.getKopaczFosy(1));

        Craftings.setItem(13, GeneratorStoneBlock.getGeneratorStoneBlock(1));
        Craftings.setItem(14, CobblestoneX.getCobbleX(1));
        Craftings.setItem(15, AntNoggin.getAntiLegs(1));
        Craftings.setItem(16, new ItemStack(Material.SHIELD));


        return Craftings;
    }
}
