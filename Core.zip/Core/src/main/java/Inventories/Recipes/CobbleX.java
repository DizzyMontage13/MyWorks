package Inventories.Recipes;

import Utils.*;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.Arrays;

public class CobbleX {

    public static Inventory CobblestoneXRecipe;


    public static Inventory OpenCobblestoneXRecipe(Player player) {

        CobblestoneXRecipe = Bukkit.createInventory(null,6*9, TextUtils.corolize("&7» &7&lCOBBLE&a&lX &f&lCRAFTING &7«"));

        for (int i =0; i < 6*9; i++) {
            CobblestoneXRecipe.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }


        CobblestoneXRecipe.setItem(10, new ItemBuilder(Material.COBBLESTONE).setAmount(64).build());
        CobblestoneXRecipe.setItem(11, new ItemBuilder(Material.COBBLESTONE).setAmount(64).build());
        CobblestoneXRecipe.setItem(12, new ItemBuilder(Material.COBBLESTONE).setAmount(64).build());

        CobblestoneXRecipe.setItem(19, new ItemBuilder(Material.COBBLESTONE).setAmount(64).build());
        CobblestoneXRecipe.setItem(20, new ItemBuilder(Material.COBBLESTONE).setAmount(64).build());
        CobblestoneXRecipe.setItem(21, new ItemBuilder(Material.COBBLESTONE).setAmount(64).build());

        CobblestoneXRecipe.setItem(28, new ItemBuilder(Material.COBBLESTONE).setAmount(64).build());
        CobblestoneXRecipe.setItem(29, new ItemBuilder(Material.COBBLESTONE).setAmount(64).build());
        CobblestoneXRecipe.setItem(30, new ItemBuilder(Material.COBBLESTONE).setAmount(64).build());

        CobblestoneXRecipe.setItem(23, new ItemStackBuilder(Material.PLAYER_HEAD).setHead("CHEATINGEGIRL").setDisplayName(" ").build());

        CobblestoneXRecipe.setItem(25, CobblestoneX.getCobbleX(1));
        CobblestoneXRecipe.setItem(34, new ItemBuilder(Material.CRAFTING_TABLE).setTitle(TextUtils.corolize("&7» &e&lAUTO CRAFTING &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &fPotrzebne itemy :"),
                TextUtils.corolize("&7» &f9x64 &8(576) &7cobblestone"),
                " "
        )).build());

        CobblestoneXRecipe.setItem(49, new ItemBuilder(Material.BARRIER).setTitle(TextUtils.corolize("&c&lPOWROT")).build());


        return CobblestoneXRecipe;
    }
}
