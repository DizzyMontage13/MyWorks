package Inventories.Recipes;

import Events.GenerateStone;
import Utils.GeneratorStoneBlock;
import Utils.ItemBuilder;
import Utils.ItemStackBuilder;
import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;

public class GSrecipe {

    public static Inventory GeneratorStoneRecipe;


    public static Inventory OpenGSRecipe(Player player) {

        GeneratorStoneRecipe = Bukkit.createInventory(null,6*9, TextUtils.corolize("&7» &c&lGENERATOR STONE &7«"));

        for (int i =0; i < 6*9; i++) {
            GeneratorStoneRecipe.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }


        GeneratorStoneRecipe.setItem(10, new ItemBuilder(Material.STONE).build());
        GeneratorStoneRecipe.setItem(11, new ItemBuilder(Material.STONE).build());
        GeneratorStoneRecipe.setItem(12, new ItemBuilder(Material.STONE).build());

        GeneratorStoneRecipe.setItem(19, new ItemBuilder(Material.STONE).build());
        GeneratorStoneRecipe.setItem(20, new ItemBuilder(Material.STONE).build());
        GeneratorStoneRecipe.setItem(21, new ItemBuilder(Material.STONE).build());

        GeneratorStoneRecipe.setItem(28, new ItemBuilder(Material.STONE).build());
        GeneratorStoneRecipe.setItem(29, new ItemBuilder(Material.STONE).build());
        GeneratorStoneRecipe.setItem(30, new ItemBuilder(Material.STONE).build());

        GeneratorStoneRecipe.setItem(23, new ItemStackBuilder(Material.PLAYER_HEAD).setHead("CHEATINGEGIRL").setDisplayName(" ").build());

        GeneratorStoneRecipe.setItem(25, GeneratorStoneBlock.getGeneratorStoneBlock(1));
        GeneratorStoneRecipe.setItem(34, new ItemBuilder(Material.CRAFTING_TABLE).setTitle(TextUtils.corolize("&7» &e&lAUTO CRAFTING &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &fPotrzebne itemy :"),
                TextUtils.corolize("&7» &f9x &8stone"),
                " "
        )).build());

        GeneratorStoneRecipe.setItem(49, new ItemBuilder(Material.BARRIER).setTitle(TextUtils.corolize("&c&lPOWROT")).build());


        return GeneratorStoneRecipe;
    }
}
