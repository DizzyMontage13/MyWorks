package Inventories;

import Utils.ItemBuilder;
import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class Test {


    public static void check(Player player) {
        Inventory check = Bukkit.createInventory(null, 6*9, TextUtils.corolize("&7» &eTESTER &7«"));

        for (int i = 0; i < 6*9; i++) {
            check.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle("SLOT:" + i).build());
        }

        player.openInventory(check);

    }
}
