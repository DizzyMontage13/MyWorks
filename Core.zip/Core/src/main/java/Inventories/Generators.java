package Inventories;


import Utils.FarmerBlock;
import Utils.GeneratorStoneBlock;
import Utils.PremiumCaseBlock;
import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;


public class Generators {

    public static Inventory generators;

    public static Inventory openGeneratorsGui(Player player) {

        generators = Bukkit.createInventory(null, 3*9, TextUtils.corolize("&7» &2&lGENERATORY &7«"));

        generators.setItem(0, FarmerBlock.getSandFarmer(64));
        generators.setItem(9, FarmerBlock.getSandFarmer(64));
        generators.setItem(18, FarmerBlock.getSandFarmer(64));

        generators.setItem(1, FarmerBlock.getBoyFarmer(64));
        generators.setItem(10, FarmerBlock.getBoyFarmer(64));
        generators.setItem(19, FarmerBlock.getBoyFarmer(64));

        generators.setItem(2, FarmerBlock.getKopaczFosy(64));
        generators.setItem(11, FarmerBlock.getKopaczFosy(64));
        generators.setItem(20, FarmerBlock.getKopaczFosy(64));

        generators.setItem(3, GeneratorStoneBlock.getGeneratorStoneBlock(64));
        generators.setItem(12, GeneratorStoneBlock.getGeneratorStoneBlock(64));
        generators.setItem(21, GeneratorStoneBlock.getGeneratorStoneBlock(64));

        generators.setItem(4, PremiumCaseBlock.getPremiumCases(64));
        generators.setItem(13, PremiumCaseBlock.getPremiumCases(64));
        generators.setItem(22, PremiumCaseBlock.getPremiumCases(64));



        return generators;

    }
}
