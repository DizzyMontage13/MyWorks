package Inventories;

import Components.Drop;
import Components.RandomDropData;
import Utils.ItemBuilder;
import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;

public class StoneDrop {

    public static Inventory stoneDrop;


    public static void show(Player player) {

        stoneDrop = Bukkit.createInventory(null, 6*9, TextUtils.corolize("&7» &2&lDROP &7«"));

        for(int i = 0; i <= 8; i++) {
            stoneDrop.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        for(int i = 9; i < 6*9; i += 9) {
            stoneDrop.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        for(int i = 8; i < 6*9; i += 9) {
            stoneDrop.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        for(int i = 45; i < 6*9; i ++) {
            stoneDrop.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        for(Drop drop : RandomDropData.getDrops()) {
            double chance = drop.getChance();

            stoneDrop.addItem(new ItemBuilder(drop.getWhat().getType()).setTitle(TextUtils.corolize("&" + drop.getColor() + "&l" + drop.getName())).addLores(Arrays.asList (
                    " ",
                    TextUtils.corolize("&8» &7Szansa na drop&8: &f" + chance + "%"),
                    TextUtils.corolize("&8» &7Fortuna&8: &a&lTAK"),
                    TextUtils.corolize("&8» &7Drop przedmiotu&8: " + (drop.isDisabled(player.getUniqueId()) ? "&c&lWYLACZONY" : "&a&lWLACZONY")),
                    " "
                    )).build());
        }

        stoneDrop.setItem(37, new ItemBuilder(Material.GREEN_SHULKER_BOX).setTitle(TextUtils.corolize("&8» &7● &a&lWLACZ &7&l WSZYSTKIE DROPY &7● &8«")).addLores(Arrays.asList(
                "",
                TextUtils.corolize("&8» &fKliknij aby &aWlaczyc &fwszystkie dropy"),
                ""
        )).build());

        stoneDrop.setItem(38, new ItemBuilder(Material.RED_SHULKER_BOX).setTitle(TextUtils.corolize("&8» &7● &c&lWYLACZ &7&lWSZYSTKIE DROPY &7● &8«")).addLores(Arrays.asList(
                "",
                TextUtils.corolize("&8» &fKliknij aby &cWylaczyc &fwszystkie dropy"),
                ""
        )).build());
        //.addEnchantment(Enchantment.SOUL_SPEED,1)


        stoneDrop.setItem(41, new ItemBuilder(Material.BOOK).setTitle(TextUtils.corolize("&8» &7● &a&lWLACZ &7&l WSZYSTKIE DROPY &7● &8«")).addLores(Arrays.asList(
                "",
                TextUtils.corolize("&8» &fTurbodropy i inne"),
                ""
        )).build());

        ItemStack messaging = new ItemBuilder(Material.PAPER).setTitle(TextUtils.corolize("&8» &7● &f&lZarzadzaj wiadomosciami &7● &8«")).addLores(Arrays.asList(
                "",
                TextUtils.corolize("&8» &7Aktualnie wiadomosci sa " + (RandomDropData.isNoMessages(player.getUniqueId()) ? "&c&lWYLACZONE" : "&a&lWLACZONE")),
                ""
        )).build();

        ItemStack cobblestone = new ItemBuilder(Material.COBBLESTONE).setTitle(TextUtils.corolize("&8» &7● &f&lZarzadzaj dropem cobblestone &7● &8«")).addLores(Arrays.asList(
                "",
                TextUtils.corolize("&8» &7Aktualnie drop cobllestone jest " + (RandomDropData.isNoCobble(player.getUniqueId()) ? "&c&lWYLACZONY" : "&a&lWLACZONY")),
                ""
        )).build();

//        if(!RandomDropData.isNoMessages(player.getUniqueId())) {
//            messaging.addEnchantment(Enchantment.SOUL_SPEED,1);
//        }
//
//        if(!RandomDropData.isNoCobble(player.getUniqueId())) {
//            cobblestone.addEnchantment(Enchantment.SOUL_SPEED,1);
//        }

        stoneDrop.setItem(42, messaging);
        stoneDrop.setItem(43, cobblestone);

        player.openInventory(stoneDrop);
    }


}
