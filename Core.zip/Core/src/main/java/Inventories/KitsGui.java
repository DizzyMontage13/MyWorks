package Inventories;

import Inventories.Kit.PlayerKit;
import Kits.KitGracz;
import Kits.KitVip;
import Utils.ItemBuilder;
import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.Arrays;

public class KitsGui {

    public static Inventory kits;

    public static Inventory openKitGui(Player player) {

        KitVip kitVip = new KitVip();

        KitGracz kitGracz = new KitGracz();

        kits = Bukkit.createInventory(null, 5*9, TextUtils.corolize("&7» &e&lKITY &7«"));

        for(int i = 0; i < 5*9; i++) {
            kits.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        kits.setItem(10, new ItemBuilder(Material.STONE_PICKAXE).setTitle(TextUtils.corolize("&7&l» &f&lKIT &e&lGRACZ &7&l«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7&l» &fLPM &7- &eAby Odebrac Kit &e&lGRACZ"),
                TextUtils.corolize("&7&l» &fPPM &7- &eAby zobaczyc co posiada kit &e&lGRACZ"),
                " ",
                TextUtils.corolize("&7&l» &fDostępność: " + kitGracz.accesForKit(player)),
                " ",
                TextUtils.corolize("&7&l» &f&lKIT &e&lGRACZ &7&l«")
        )).build());

        kits.setItem(12, new ItemBuilder(Material.IRON_PICKAXE).setTitle(TextUtils.corolize("&7&l» &f&lKIT &6&lVIP &7&l«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7&l» &fLPM &7- &eAby Odebrac Kit &6&lVIP"),
                TextUtils.corolize("&7&l» &fPPM &7- &eAby zobaczyc co posiada kit &6&lVIP"),
                " ",
                TextUtils.corolize("&7&l» &fDostępność: " + kitVip.accesForKit(player)),
                " ",
                TextUtils.corolize("&7&l» &f&lKIT &6&lVIP &7&l«")
        )).build());

        kits.setItem(14, new ItemBuilder(Material.GOLDEN_PICKAXE).setTitle(TextUtils.corolize("&7&l» &f&lKIT &5&lS&6&lVIP &7&l«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7&l» &fLPM &7- &eAby Odebrac Kit &5&lS&6&lVIP"),
                TextUtils.corolize("&7&l» &fPPM &7- &eAby zobaczyc co posiada kit &5&lS&6&lVIP"),
                " ",
                TextUtils.corolize("&7&l» &f&lKIT &5&lS&6&lVIP &7&l«")
        )).build());

        kits.setItem(16, new ItemBuilder(Material.DIAMOND_PICKAXE).setTitle(TextUtils.corolize("&7&l» &f&lKIT &c&lY&f&lT &7&l«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7&l» &fLPM &7- &eAby Odebrac Kit &c&lY&f&lT"),
                TextUtils.corolize("&7&l» &fPPM &7- &eAby zobaczyc co posiada kit &c&lY&f&lT"),
                " ",
                TextUtils.corolize("&7&l» &f&lKIT &c&lY&f&lT &7&l«")
        )).build());

        kits.setItem(29, new ItemBuilder(Material.OAK_WOOD).setTitle(TextUtils.corolize("&7&l» &f&lKIT &6&lDREWNO &7&l«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7&l» &fLPM &7- &eAby Odebrac Kit &6&lDREWNO"),
                TextUtils.corolize("&7&l» &fPPM &7- &eAby zobaczyc co posiada kit &6&lDREWNO"),
                " ",
                TextUtils.corolize("&7&l» &f&lKIT &6&lDREWNO &7&l«")
        )).build());

        kits.setItem(31, new ItemBuilder(Material.PUMPKIN_PIE).setTitle(TextUtils.corolize("&7&l» &f&lKIT &e&lJEDZENIE &7&l«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7&l» &fLPM &7- &eAby Odebrac Kit &e&lJEDZENIE"),
                TextUtils.corolize("&7&l» &fPPM &7- &eAby zobaczyc co posiada kit &e&lJEDZENIE"),
                " ",
                TextUtils.corolize("&7&l» &f&lKIT &e&lJEDZENIE &7&l«")
        )).build());

        kits.setItem(33, new ItemBuilder(Material.STONE).setTitle(TextUtils.corolize("&7&l» &f&lKIT &a&lSTONIARKA &7&l«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7&l» &fLPM &7- &eAby Odebrac Kit &a&lSTONIARKA"),
                TextUtils.corolize("&7&l» &fPPM &7- &eAby zobaczyc co posiada kit &a&lSTONIARKA"),
                " ",
                TextUtils.corolize("&7&l» &f&lKIT &a&lSTONIARKA &7&l«")
        )).build());

        return kits;

    }
}
