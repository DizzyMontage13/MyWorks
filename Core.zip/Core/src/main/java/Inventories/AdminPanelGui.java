package Inventories;

import Utils.ItemBuilder;
import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.Arrays;

public class AdminPanelGui {

    public static Inventory adminpanelgui;


    public static Inventory OpenInventoryAdminPanelGui(Player player) {
        adminpanelgui = Bukkit.createInventory(null, 3*9, TextUtils.corolize("&7» &c&lADMINPANEL &7«"));
        for(int i = 0; i < 27; i++) {
            adminpanelgui.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        adminpanelgui.setItem(10, new ItemBuilder(Material.END_PORTAL_FRAME).setTitle(TextUtils.corolize("&7» &2&lGENERATORY &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &e&lKLIKNIJ ABY ODEBRAC GENERATORY "),
                " ",
                TextUtils.corolize("&7» &2&lGENERATORY &7«")
        )).build());

        adminpanelgui.setItem(12, new ItemBuilder(Material.OAK_SIGN).setTitle(TextUtils.corolize("&7» &3&lZARZĄDZANIE CHATEM &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &e&lKLIKNIJ ABY ZARZĄDZAĆ CHATEM "),
                " ",
                TextUtils.corolize("&7» &3&lZARZĄDZANIE CHATEM &7«")
        )).build());

        adminpanelgui.setItem(14, new ItemBuilder(Material.END_CRYSTAL).setTitle(TextUtils.corolize("&7» &A&lZARZĄDZANIE STARTEN EDYCJI &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &e&lKLIKNIJ ABY ZARZĄDZAĆ STARTEN EDYCJI "),
                " ",
                TextUtils.corolize("&7» &A&lZARZĄDZANIE STARTEN EDYCJI &7«")
        )).build());

        adminpanelgui.setItem(16, new ItemBuilder(Material.BARRIER).setTitle(TextUtils.corolize("&7» &c&lWKRÓTCE &7«")).addLores(Arrays.asList (
                " ",
                TextUtils.corolize("&7» &e&lKLIKNIJ ABY ZARZĄDZAĆ &c&lWKRÓTCE "),
                " ",
                TextUtils.corolize("&7» &c&lWKRÓTCE &7«")
        )).build());

        return adminpanelgui;
    }
}
