package Inventories.Kit;

import Utils.ItemBuilder;
import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class VipKit {


    public static Inventory KitVip;
    
    

    public static Inventory VipKits() {
        KitVip = Bukkit.createInventory(null, 6*9, TextUtils.corolize("&7&l» &f&lKIT &e&lGRACZ &7&l«"));

        for(int i = 0; i <= 8; i++) {
            KitVip.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        for(int i = 9; i< 6*9; i += 9) {
            KitVip.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        for(int i = 8; i< 6*9; i += 9) {
            KitVip.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        for(int i = 37; i< 6*9; i ++) {
            KitVip.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        KitVip.setItem(10, new ItemBuilder(Material.IRON_SWORD).setTitle(TextUtils.corolize("&7&l» &f&lŻELAZNY MIECZ &7&l«")).addEnchantment(Enchantment.DAMAGE_ALL, 4).addEnchantment(Enchantment.DURABILITY, 2).addEnchantment(Enchantment.FIRE_ASPECT, 1).build());
        KitVip.setItem(11, new ItemBuilder(Material.IRON_HELMET).setTitle(TextUtils.corolize("&7&l» &f&lŻELAZNA CZAPA &7&l«")).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3).addEnchantment(Enchantment.DURABILITY, 2).build());
        KitVip.setItem(12, new ItemBuilder(Material.IRON_CHESTPLATE).setTitle(TextUtils.corolize("&7&l» &f&lŻELAZNA KLATA &7&l«")).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3).addEnchantment(Enchantment.DURABILITY, 2).build());
        KitVip.setItem(13, new ItemBuilder(Material.IRON_LEGGINGS).setTitle(TextUtils.corolize("&7&l» &f&lŻELAZNE SPODNIE &7&l«")).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3).addEnchantment(Enchantment.DURABILITY, 2).build());
        KitVip.setItem(14, new ItemBuilder(Material.IRON_BOOTS).setTitle(TextUtils.corolize("&7&l» &f&lŻELAZNE BUTY &7&l«")).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 3).addEnchantment(Enchantment.DURABILITY, 2).build());
        KitVip.setItem(15, new ItemBuilder(Material.DIAMOND_PICKAXE).setTitle(TextUtils.corolize("&7&l» &3&lDIAMENTOWY KILOF &7&l«")).addEnchantment(Enchantment.DIG_SPEED, 4).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.LOOT_BONUS_BLOCKS, 3).build());
        KitVip.setItem(16, new ItemBuilder(Material.SHIELD).setTitle(TextUtils.corolize("&7&l» &8&lTARCZA &7&l«")).addEnchantment(Enchantment.DURABILITY, 2).build());
        KitVip.setItem(19, new ItemBuilder(Material.GOLDEN_APPLE).setTitle(TextUtils.corolize("&7&l» &b&lZŁOTE JABŁKA &7&l«")).setAmount(3).build());
        KitVip.setItem(20, new ItemBuilder(Material.PUMPKIN_PIE).setTitle(TextUtils.corolize("&7&l» &6&lJEDZENIE &7&l«")).setAmount(16).build());
        KitVip.setItem(21, new ItemBuilder(Material.ENDER_PEARL).setTitle(TextUtils.corolize("&7&l» &1&lENDER PERŁY &7&l«")).setAmount(2).build());
        KitVip.setItem(22, new ItemBuilder(Material.BOW).setTitle(TextUtils.corolize("&7&l» &e&lŁUK &7&l«")).addEnchantment(Enchantment.ARROW_DAMAGE, 4).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.ARROW_INFINITE, 1).build());
        KitVip.setItem(23, new ItemBuilder(Material.ARROW).setTitle(TextUtils.corolize("&7&l» &8&lSTRZAŁA &7&l«")).build());


        KitVip.setItem(49, new ItemBuilder(Material.BARRIER).setTitle(TextUtils.corolize("&7&l» &c&lPOWROT &7&l«")).build());


        return KitVip;
    }
}
