package Inventories.Kit;

import Utils.ItemBuilder;
import Utils.TextUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class PlayerKit {

    public static Inventory playerkit;

    public static Inventory PlayerKits() {
        playerkit = Bukkit.createInventory(null, 6*9, TextUtils.corolize("&7&l» &f&lKIT &e&lGRACZ &7&l«"));

        for(int i = 0; i <= 8; i++) {
            playerkit.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        for(int i = 9; i< 6*9; i += 9) {
            playerkit.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        for(int i = 8; i< 6*9; i += 9) {
            playerkit.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        for(int i = 37; i< 6*9; i ++) {
            playerkit.setItem(i, new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).setTitle(" ").build());
        }

        playerkit.setItem(10, new ItemBuilder(Material.STONE_SWORD).setTitle(TextUtils.corolize("&7&l» &8&lKAMIENNY MIECZ &7&l«")).build());
        playerkit.setItem(11, new ItemBuilder(Material.LEATHER_CHESTPLATE).setTitle(TextUtils.corolize("&7&l» &8&lSKÓRZANY NAPIERŚNIK &7&l«")).build());
        playerkit.setItem(12, new ItemBuilder(Material.PUMPKIN_PIE).setTitle(TextUtils.corolize("&7&l» &6&lJEDZENIE &7&l«")).setAmount(16).build());
        playerkit.setItem(13, new ItemBuilder(Material.IRON_PICKAXE).setTitle(TextUtils.corolize("&7&l» &f&lŻELAZNY KILOF &7&l«")).addEnchantment(Enchantment.DIG_SPEED, 3).addEnchantment(Enchantment.DURABILITY, 2).build());
        playerkit.setItem(14, new ItemBuilder(Material.TORCH).setTitle(TextUtils.corolize("&7&l» &e&lPOCHODNIE &7&l«")).setAmount(16).build());
        playerkit.setItem(15, new ItemBuilder(Material.ENDER_CHEST).setTitle(TextUtils.corolize("&7&l» &5&lENDERCHEST &7&l«")).build());



        playerkit.setItem(49, new ItemBuilder(Material.BARRIER).setTitle(TextUtils.corolize("&7&l» &c&lPOWROT &7&l«")).build());

        return playerkit;
    }


}
