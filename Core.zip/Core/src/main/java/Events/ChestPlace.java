package Events;


import Components.CaseDropData;
import Utils.ItemBuilder;
import Utils.ItemStackBuilder;
import Utils.PremiumCaseBlock;
import Utils.Randomizer;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Objects;
import java.util.Random;


public class ChestPlace implements Listener {

    Main plugin;

    public ChestPlace(Main main) {
        plugin = main;
    }


    @EventHandler
    public void onPlace(BlockPlaceEvent event) {

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if(event.isCancelled()) return;

        if(item.getItemMeta() == null) return;

        if(item.getItemMeta().getLore() == null) return;

        int amount = item.getAmount();
        int amount2 = player.getInventory().getItemInOffHand().getAmount();

        if(player.getInventory().getItemInOffHand() == PremiumCaseBlock.getPremiumCases(amount2)) {
            event.setCancelled(true);
            return;
        }

        if (!item.hasItemMeta()) return;
        if(!(item.getType() == (Material.BARREL))) return;


        if (!item.equals(PremiumCaseBlock.getPremiumCases(amount))) return;


        CaseDropData.CaseDropItems(player, event.getBlock().getLocation());

        event.setCancelled(true);

        player.getInventory().removeItem(PremiumCaseBlock.getPremiumCases(1));



    }
}
