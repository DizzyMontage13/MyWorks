package Events;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class UnknowCommand implements Listener {


    Main plugin;

    public UnknowCommand(Main main) {
        main = plugin;
    }


    @EventHandler
    public static void onUnknowCommand(PlayerCommandPreprocessEvent event) {
        String message = event.getMessage();
        String[] args = message.split(" ");
        Player player = event.getPlayer();

        if(Bukkit.getServer().getHelpMap().getHelpTopic(args[0]) == null) {
            event.setCancelled(true);

            player.sendMessage(TextUtils.Wrong("&7Nieznana komenda. &e/pomoc"));
        }
    }
}
