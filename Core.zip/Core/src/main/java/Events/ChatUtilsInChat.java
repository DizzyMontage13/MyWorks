package Events;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatUtilsInChat implements Listener {

    Main main;

    public ChatUtilsInChat(Main plugin) {
        main = plugin;
    }

    @EventHandler
    public void ChatTranslateColors(AsyncPlayerChatEvent event) {

        Player player = event.getPlayer();

        if(player.isOp() || player.hasPermission("dizzyCore.ChatColored")) {
            String message = event.getMessage();

            String chatmessage = TextUtils.corolize(message);

            event.setMessage(chatmessage);
        }
    }
}
