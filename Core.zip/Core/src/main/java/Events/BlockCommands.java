package Events;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import java.util.Arrays;

public class BlockCommands implements Listener {

    Main plugin;

    public BlockCommands(Main main) {
        plugin = main;
    }

    static String[] blockedCommands =  {
            "/pl",
            "/plugins",
            "/help",
            "/?",
            "list",
            "icanhasbukkit",
            "ver",
            "version"
    };

    static String[] blockedStartCommands = {
            "bukkit",
            "minecraft",
            "ver",
            "about",
            "icanhasbukkit",
            "me",
            "version"
    };


    @EventHandler
    public static void onComamnd(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        String message = event.getMessage();
        String[] args = message.split(" ");

        boolean blocked = false;

        if(Arrays.asList(blockedCommands).contains(args[0].toLowerCase())) {
            blocked = true;
        }

        for(String string : blockedStartCommands) {
            if(args[0].toLowerCase().startsWith(string)) {
                blocked = false;
            }
        }

        if(blocked && !player.isOp()) {
            event.setCancelled(true);
            player.sendMessage(TextUtils.Wrong("&7Nie mozesz uzyc tej komendy!"));
        }
    }
}
