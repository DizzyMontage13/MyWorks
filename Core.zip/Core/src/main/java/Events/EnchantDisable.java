package Events;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

public class EnchantDisable implements Listener {

    Main plugin;

    FileConfiguration main = Main.getMain().getConfig();

    public EnchantDisable(Main main) {
        plugin = main;
    }

    @EventHandler
    public void EnchantEvent(PlayerInteractEvent event) {
        if(!(event.getAction() == Action.RIGHT_CLICK_BLOCK)) return;

        if(!plugin.getConfig().getBoolean("enchanting")) return;

        Player player = event.getPlayer();
        Block block = event.getClickedBlock();

        assert block != null;
        if(block.getType().equals(Material.ENCHANTING_TABLE)) {
            event.setCancelled(true);
            player.sendMessage(TextUtils.Wrong("&5&lENCHANT &7jest &c&lWYŁĄCZONY!"));
        }

    }

}
