package Events;

import commands.admin.VanishCommand;
import com.Challangerson.Main;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class JoinEvent implements Listener {

    Main plugin;
    VanishCommand vanishCommand;

    public JoinEvent(Main main) {
        plugin = main;
    }

    @EventHandler
    public void JoinPlayerEvent(PlayerJoinEvent event) {

        Player player = event.getPlayer();
        vanishCommand = new VanishCommand();
        for(int i = 0; i < vanishCommand.invisible_players.size(); i++) {
            player.hidePlayer(plugin, vanishCommand.invisible_players.get(i));
        }
    }

    @EventHandler
    public void FirstJoinEvent(PlayerJoinEvent event) {

        Player player = event.getPlayer();

        if(!player.hasPlayedBefore()) {
    //        DropManager.createUser(player);
        } else {
            player.sendMessage("JUZ GRALES!");
        }

    }
}
