package Events;

import commands.player.TpacceptCommand;
import com.Challangerson.Main;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.HashSet;

public class MoveOnTeleport implements Listener {

    Main plugin;

    public static HashSet<Player> spawnCommand = new HashSet<>();

    public MoveOnTeleport(Main main) {
        plugin = main;
    }

    @EventHandler
    public static void PlayerMoves(PlayerMoveEvent event) {
        Player player = event.getPlayer();

        Location to = event.getTo();
        Location from = event.getFrom();


        assert to != null;
        if(to.getBlockZ() != from.getBlockZ() || to.getBlockX() != from.getBlockX() || to.getBlockY() != from.getBlockY()) {
            if(TpacceptCommand.tpacceptrequest.containsKey(player)) {
                TpacceptCommand.tpacceptrequest.remove(player);
            }
            spawnCommand.remove(player);
        }
    }

    public static void PlayerMove() {

    }
}
