package Events;

import Utils.TextUtils;
import Utils.TitleAPI;
import com.Challangerson.Main;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;

public class MoveOnCommand implements Listener {

    Main plugin;

    public Map<Player, BukkitTask> tasks = new HashMap<>();

    public MoveOnCommand(Main main) {
        plugin = main;
    }

    @EventHandler
    public void onPlayerMoveOnCommand(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (event.getFrom().getBlockX() != event.getTo().getBlockX() || event.getFrom().getBlockY() != event.getTo().getBlockY() ||
                event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
            BukkitTask task = this.tasks.get(player);

            if(task == null) return;

                TitleAPI.SendActionBar(player, "&7&l» &c&lTELEPORT PRZERWANY &7&l«");

                task.cancel();
                this.tasks.remove(player);
        }
    }

}
