package Events;

import Components.RandomDropData;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

public class Drop implements Listener {

    Main plugin;

    public Drop(Main main) {
        plugin = main;
    }


    @EventHandler
    public void BreakStone(BlockBreakEvent event) {
        if (!(event.getBlock().getType() == Material.STONE)) return;


        if (event.isCancelled()) return;

        Player player = event.getPlayer();

        if(player.getGameMode() == GameMode.CREATIVE) return;

        Location location = event.getBlock().getLocation();


        player.giveExp(1);
        location.getBlock().getWorld().spawnEntity(location, EntityType.EXPERIENCE_ORB);


        if(RandomDropData.isNoCobble(player.getUniqueId())) {
            event.setDropItems(false);
        }

        RandomDropData.DropItem(player);

    }


    @EventHandler
    public void BreakOre(BlockBreakEvent event) {
        Material block = event.getBlock().getType();

        if(block == Material.COAL_ORE ||
            block == Material.IRON_ORE ||
            block == Material.COPPER_ORE||
            block == Material.GOLD_ORE ||
            block == Material.REDSTONE_ORE ||
            block == Material.EMERALD_ORE ||
            block == Material.LAPIS_ORE ||
            block == Material.DIAMOND_ORE) {

            Block block1 = event.getBlock();
            Location loc = event.getBlock().getLocation();

            if(event.getPlayer().getGameMode() == GameMode.CREATIVE) return;

            block1.setType(Material.AIR);
            event.getPlayer().sendMessage(TextUtils.Wrong("&7Nie możesz wykopać tej rudy!"));
            block1.getWorld().dropItemNaturally(loc, new ItemStack(Material.COBBLESTONE));
        }
    }
}
