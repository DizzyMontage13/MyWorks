package Events;

import Components.PlayerData;
import Utils.GeneratorStoneBlock;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import java.util.*;

public class GenerateStone implements Listener {


    Main plugin;


    PlayerData playerData;




    public GenerateStone(Main main) {
        plugin = main;
        this.playerData = new PlayerData(main);
    }

    public String getIntXYZ(Location location) {

        World world = location.getWorld();
        int x = location.getBlockX();
        int y = location.getBlockY();
        int z = location.getBlockZ();

        return world + ":" + x + ":" + y + ":" + z;
    }


    @EventHandler
    public void CheckIfPlayerPutStoneBlock(BlockPlaceEvent event) {

        Player player = event.getPlayer();

        ItemStack itemStack = event.getItemInHand();
        int amount = itemStack.getAmount();
        Location location = event.getBlock().getLocation();

        World world = location.getWorld();

        if(!playerData.GetLocation(getIntXYZ(location))) {
            player.sendMessage(TextUtils.corolize("&c&l✘"));
            event.setCancelled(true);
            return;
        }


        if (event.getHand() != EquipmentSlot.HAND) return;


        if (itemStack.equals(GeneratorStoneBlock.getGeneratorStoneBlock(amount))) {
            Bukkit.getScheduler().runTaskLater(plugin, new Runnable() {
                @Override

                public void run() {
                        location.getBlock().setType(Material.STONE);
                }
            }, 15L);
            player.sendMessage(TextUtils.corolize("&a&l✔ &7Postawiłeś stoniarke"));

            playerData.saveLocation(getIntXYZ(location));

        }
    }

    @EventHandler
    public void DestroyStoneInStoneBlock(BlockBreakEvent event) {
        Player player = event.getPlayer();

        Location location = event.getBlock().getLocation();

        if(event.getBlock().getType() != Material.STONE) return;

        if(playerData.GetLocation(getIntXYZ(location))) return;

        Bukkit.getScheduler().runTaskLater(plugin, new Runnable() {
            @Override
            public void run() {
                if(playerData.GetLocation(getIntXYZ(location))) return;

                location.getBlock().setType(Material.STONE);
            }
        }, 35L);

        if(player.getInventory().getItemInMainHand().getType() != Material.GOLDEN_PICKAXE)  return;

        playerData.removeLocation(getIntXYZ(location));

        Objects.requireNonNull(location.getWorld()).dropItemNaturally(location, GeneratorStoneBlock.getGeneratorStoneBlock(1));
        player.sendMessage(TextUtils.corolize("&c&l✘ &7Zniszczyłeś stoniarke"));

    }



}
