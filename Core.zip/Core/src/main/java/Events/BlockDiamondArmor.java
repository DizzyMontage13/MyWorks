package Events;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;

public class BlockDiamondArmor implements Listener {

    Main plugin;

    public BlockDiamondArmor(Main main) {
        plugin = main;
    }

    @EventHandler
    public void CraftingItem(CraftItemEvent event) {
        Player player = (Player) event.getWhoClicked();
        Material material = event.getRecipe().getResult().getType();

        if(!plugin.getConfig().getBoolean("diamond-kits")) return;


            if(material == Material.DIAMOND_CHESTPLATE
                    || material == Material.DIAMOND_BOOTS
                    || material == Material.DIAMOND_HELMET
                    || material == Material.DIAMOND_LEGGINGS
                    || material == Material.DIAMOND_SWORD
                    || material == Material.DIAMOND_AXE) {
                player.sendMessage(TextUtils.Wrong("&7Sety &bDiamentowe &7są &c&lWYŁĄCZONE!"));
                event.setCancelled(true);
            }

    }
}
