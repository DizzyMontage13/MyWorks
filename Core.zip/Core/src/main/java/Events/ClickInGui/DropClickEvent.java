package Events.ClickInGui;

import Inventories.DropGui;
import Inventories.StoneDrop;
import com.Challangerson.Main;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.HashMap;
import java.util.HashSet;

public class DropClickEvent implements Listener {

    Main plugin;
    public DropClickEvent(Main main) {
        plugin = main;
    }

    public HashSet<Player> messagepcase = new HashSet<>();

    @EventHandler
    public void onDropGuiClick(InventoryClickEvent event) {

        Player player = (Player) event.getWhoClicked();


        if(event.getClickedInventory() != null) {

            if (event.getClickedInventory().equals(DropGui.drop)) {
                if (event.getClickedInventory() != null) {
                    if (event.getClickedInventory() != player.getInventory()) {
                        if (event.getRawSlot() == 10) {
                            DropGui.PremiumCaseGui(player);
                        } else if (event.getRawSlot() == 13) {
                        StoneDrop.show(player);
                        }

                        event.setCancelled(true);
                    }

                }

            }

            if (event.getClickedInventory().equals(DropGui.premiumcase)) {
                if (event.getClickedInventory() != null) {
                    for (int i = 5; i <= 7; i++) {
                        if (event.getRawSlot() == i) {
                            if(!messagepcase.contains(player)) {
                                player.sendMessage("WLACZONO POWIADOMIENIE");
                                messagepcase.add(player);
                            } else {
                                player.sendMessage("JUZ MASZ WLACZONE POWIADOMIENIE");
                            }
                        }
                    }

                    for (int i = 1; i <= 3; i++) {
                        if (event.getRawSlot() == i) {
                            if(messagepcase.contains(player)) {
                                player.sendMessage("WYLACZONO");
                                messagepcase.remove(player);
                            } else {
                                player.sendMessage("JUZ MASZ WYLACZONO");
                            }
                        }
                    }

                    event.setCancelled(true);
                }
            }

        }
    }

}
