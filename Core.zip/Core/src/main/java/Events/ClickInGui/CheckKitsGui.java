package Events.ClickInGui;

import Inventories.Kit.PlayerKit;
import Inventories.Kit.VipKit;
import Inventories.KitsGui;
import com.Challangerson.Main;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;


public class CheckKitsGui implements Listener {

    Main plugin;

    public CheckKitsGui(Main main) {
        plugin = main;
    }


    @EventHandler
    public void onKitClickEvent(InventoryClickEvent event) {


        if (event.getClickedInventory() == null) return;


        Player player = (Player) event.getWhoClicked();
        if (event.getClickedInventory() == player.getInventory()) return;

        if (event.getClickedInventory().equals(PlayerKit.playerkit) || event.getClickedInventory().equals(VipKit.KitVip)) {

            if(event.getCurrentItem() == null || event.getCurrentItem().getType().equals(Material.AIR)) return;

            if(event.getCurrentItem().getType().equals(Material.BARRIER)) {
                player.openInventory(KitsGui.openKitGui(player));
            }

            event.setCancelled(true);
        }

    }


}
