package Events.ClickInGui;

import Components.Drop;
import Components.RandomDropData;
import Inventories.StoneDrop;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class StoneDropGuiClick implements Listener {

    Main plugin;

    public StoneDropGuiClick(Main main) {

        plugin = main;

    }


    @EventHandler
    public void StoneDropClick(InventoryClickEvent event) {
        if (event.getClickedInventory() == null) return;

        Player player = (Player) event.getWhoClicked();

        if (event.getClickedInventory() == player.getInventory()) return;

        if(!event.getClickedInventory().equals(StoneDrop.stoneDrop)) return;

        event.setCancelled(true);

        ItemStack itemStack = event.getCurrentItem();

        if(itemStack == null) return;

        ItemMeta meta = itemStack.getItemMeta();

        if(meta == null) return;

        Drop drop = RandomDropData.getDropByName(ChatColor.stripColor(TextUtils.corolize(meta.getDisplayName())));

        if(drop != null) {
            drop.changeStatus(player.getUniqueId());
            StoneDrop.show(player);
            return;
        }

        int rawSlot = event.getRawSlot();

        if (rawSlot == 37) {
            for (Drop d : RandomDropData.getDrops()) {
                d.setStatus(player.getUniqueId(), true);
            }
            player.sendMessage("DADS");
            StoneDrop.show(player);
            return;
        }

        if (rawSlot == 38) {
            for (Drop d : RandomDropData.getDrops()) {
                d.setStatus(player.getUniqueId(), false);
            }
            StoneDrop.show(player);
            player.sendMessage("DAD1");
            return;
        }
        if (rawSlot == 42) {
            RandomDropData.changeMessages(player.getUniqueId());
            StoneDrop.show(player);
            player.sendMessage("DAD");
            return;

        }
        if (rawSlot == 43) {
            player.sendMessage("DADA");
            RandomDropData.changeNoCobble(event.getWhoClicked().getUniqueId());
            StoneDrop.show(player);
        }
    }
}
