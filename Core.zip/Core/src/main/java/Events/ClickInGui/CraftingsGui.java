package Events.ClickInGui;

import Inventories.Recipes.BoyFarmersRecipes;
import Inventories.Recipes.CobbleX;
import Inventories.Recipes.Craftings;
import Inventories.Recipes.GSrecipe;
import com.Challangerson.Main;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class CraftingsGui implements Listener {

    Main plugin;

    public CraftingsGui(Main main) {
        plugin = main;
    }

    @EventHandler
    public void onKitClickEvent(InventoryClickEvent event) {


        if (event.getClickedInventory() == null) return;


        Player player = (Player) event.getWhoClicked();

        if (event.getClickedInventory() == player.getInventory()) return;

        if (event.getClickedInventory().equals(Craftings.Craftings)) {

            if(event.getCurrentItem() == null || event.getCurrentItem().getType().equals(Material.AIR)) return;

            switch (event.getRawSlot()) {
                case 10:
                    player.openInventory(BoyFarmersRecipes.OpenBoyFarmer(player));
                    break;
                case 11:
                    player.openInventory(BoyFarmersRecipes.OpenSandFarmer(player));
                    break;
                case 12:
                    player.openInventory(BoyFarmersRecipes.OpenDiggerFossa(player));
                    break;
                case 13:
                    player.openInventory(GSrecipe.OpenGSRecipe(player));
                    break;
                case 14:
                    player.openInventory(CobbleX.OpenCobblestoneXRecipe(player));
                    break;
                case 15:
                    player.closeInventory();
                    break;
                case 16:
                    player.openInventory(Craftings.OpenCraftings(player));
                    break;
            }

            event.setCancelled(true);
        }

    }
}
