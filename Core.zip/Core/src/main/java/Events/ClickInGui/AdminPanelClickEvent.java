package Events.ClickInGui;

import Inventories.AdminPanelGui;
import Inventories.Generators;
import Inventories.StartEditionGui;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class AdminPanelClickEvent implements Listener {

    Main plugin;


    public AdminPanelClickEvent(Main main) {
        plugin = main;
    }

    Main main = Main.getMain();

    @EventHandler
    public void AdminPanelClick(InventoryClickEvent event) {
        if (event.getClickedInventory() == null) return;


        Player player = (Player) event.getWhoClicked();

        if (event.getClickedInventory() == player.getInventory()) return;

        if(event.getClickedInventory().equals(AdminPanelGui.adminpanelgui)) {

            if(event.getRawSlot() == 14) {
                player.openInventory(StartEditionGui.Guieditionstart());
            }

            if(event.getRawSlot() == 10) {
                player.openInventory(Generators.openGeneratorsGui(player));
            }

            event.setCancelled(true);
        }


        if(event.getClickedInventory().equals(StartEditionGui.editionstart)) {

                boolean diamondback = main.getConfig().getBoolean("diamond-kits");
                boolean enchanting = main.getConfig().getBoolean("enchanting");
                boolean kits = main.getConfig().getBoolean("kits");

                switch (event.getRawSlot()) {
                    case 10:
                        if(diamondback) {
                            main.getConfig().set("diamond-kits", false);
                            player.sendMessage(TextUtils.corolize("&A&LWŁĄCZONO &B&LDIAX SETY"));
                        } else {
                            main.getConfig().set("diamond-kits", true);
                            player.sendMessage(TextUtils.corolize("&c&lWYŁĄCZONO &B&LDIAX SETY"));
                        }
                        main.saveConfig();
                        break;
                    case 12:
                        if(enchanting) {
                            main.getConfig().set("enchanting", false);
                            player.sendMessage(TextUtils.corolize("&A&LWŁĄCZONO &e&lENCHANTOWANIE"));
                        } else {
                            main.getConfig().set("enchanting", true);
                            player.sendMessage(TextUtils.corolize("&c&lWYŁĄCZONO &e&lENCHANTOWANIE"));
                        }
                        main.saveConfig();
                        break;
                    case 13:
                        if(kits) {
                            main.getConfig().set("kits", false);
                            player.sendMessage(TextUtils.corolize("&c&lWYŁĄCZONO &b&lKITY"));
                        } else {
                            main.getConfig().set("kits", true);
                            player.sendMessage(TextUtils.corolize("&A&LWŁĄCZONO &b&lKITY"));
                        }
                        main.saveConfig();
                        break;
                }

                event.setCancelled(true);
            }
        }
    }
