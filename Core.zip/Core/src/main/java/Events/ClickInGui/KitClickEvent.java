package Events.ClickInGui;

import Inventories.Kit.PlayerKit;
import Inventories.Kit.VipKit;
import Inventories.KitsGui;
import Kits.KitGracz;
import Kits.KitVip;
import com.Challangerson.Main;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class KitClickEvent implements Listener{

    Main plugin;





    public KitClickEvent(Main main) {

        plugin = main;

    }


    @EventHandler
    public void onKitClickEvent(InventoryClickEvent event) {


        if (event.getClickedInventory() == null) return;

        Player player = (Player) event.getWhoClicked();

        if (event.getClickedInventory() == player.getInventory()) return;

        if(KitsGui.kits == null) return;

        if (!KitsGui.kits.equals(event.getClickedInventory())) return;

        if(event.isRightClick()) {

            switch (event.getCurrentItem().getType()) {
                case STONE_PICKAXE:
                    player.openInventory(PlayerKit.PlayerKits());
                    break;
                case IRON_PICKAXE:
                    player.openInventory(VipKit.VipKits());
                    break;
                case GOLDEN_PICKAXE:
                    player.sendMessage("Kliknieto kit svip");
                    break;
                case DIAMOND_PICKAXE:
                    player.sendMessage("Kliknieto kit yt");
                    break;
                case OAK_WOOD:
                    player.sendMessage("Kliknieto kit drewno");
                    break;
                case PUMPKIN_PIE:
                    player.sendMessage("Kliknieto kit jedzenie");
                    break;
                case STONE:
                    player.sendMessage("Kliknieto kit stoniarki");
                    break;
            }
        }else if (event.isLeftClick()) {
            switch (event.getCurrentItem().getType()) {
                case STONE_PICKAXE:

                    KitGracz kitGracz = new KitGracz();
                    kitGracz.CheckKitGracz(player);

                    break;
                case IRON_PICKAXE:

                    KitVip kitVip = new KitVip();
                    kitVip.CheckKitVip(player);

                    break;
                case GOLDEN_PICKAXE:
                    player.sendMessage("Kliknieto kit svip");
                    break;
                case DIAMOND_PICKAXE:
                    player.sendMessage("Kliknieto kit yt");
                    break;
                case OAK_WOOD:
                    player.sendMessage("Kliknieto kit drewno");
                    break;
                case PUMPKIN_PIE:
                    player.sendMessage("Kliknieto kit jedzenie");
                    break;
                case STONE:
                    player.sendMessage("Kliknieto kit stoniarki");
                    break;
            }
        }

                    event.setCancelled(true);
                }




//    @EventHandler
//    public void onSpecificKitGuiClick(InventoryClickEvent event) {
//        Player player = (Player) event.getWhoClicked();
//
//        if (event.getClickedInventory().equals(PlayerKit.playerkit) || event.getClickedInventory().equals(VipKit.VipKits())) {
//            if (event.getClickedInventory() != null) {
//                if (event.getClickedInventory() != player.getInventory()) {
//                    if(event.getCurrentItem() != null  && event.getCurrentItem().getType() != Material.AIR) {
//                        if(event.getCurrentItem().getType().equals(Material.BARRIER)) {
//                            player.openInventory(VipKit.VipKits());
//                        }
//                        event.setCancelled(true);
//                    }
//                }
//            }
//        }
//    }
}
