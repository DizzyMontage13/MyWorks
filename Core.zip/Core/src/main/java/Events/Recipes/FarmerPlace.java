package Events.Recipes;

import Utils.FarmerBlock;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;

public class FarmerPlace implements Listener {

    Main plugin;

    public FarmerPlace(Main main) {
        plugin = main;
    }

    @EventHandler
    public void PlaceSandFarmer(BlockPlaceEvent event) {
        if (event.isCancelled()) return;

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        int amount = item.getAmount();
        int amount2 = player.getInventory().getItemInOffHand().getAmount();

        if(player.getInventory().getItemInOffHand() == FarmerBlock.getKopaczFosy(amount2)) {
            event.setCancelled(true);
            return;
        }

        if (item.getType() != Material.YELLOW_GLAZED_TERRACOTTA) return;
        if (!item.hasItemMeta()) return;
        if(!item.equals(FarmerBlock.getSandFarmer(amount))) return;

        Block block = event.getBlock();


        block.setType(Material.SAND);
        for(int y = block.getY(); y > 0; y--) {

            Location location1 = new Location(player.getLocation().getWorld(), block.getX(), y, block.getZ());
            Block block1 = location1.getBlock();

            if(block1.getType().equals(Material.AIR) || block1.getType().equals(Material.YELLOW_GLAZED_TERRACOTTA) || block1.getType().equals(Material.SAND)) {
                block1.setType(Material.SAND);
            } else {
                player.sendMessage(TextUtils.Wrong("&e&lSANDFARMER &7zakonczyl pracę, ponieważ napotkał &cproblem"));
                y = 0;
            }
        }

        player.getInventory().removeItem(FarmerBlock.getSandFarmer(1));
    }

    @EventHandler
    public void PlaceBoyFarmer(BlockPlaceEvent event) {
        if (event.isCancelled()) return;

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        int amount = item.getAmount();
        int amount2 = player.getInventory().getItemInOffHand().getAmount();

        if(player.getInventory().getItemInOffHand() == FarmerBlock.getKopaczFosy(amount2)) {
            event.setCancelled(true);
            return;
        }

        if (item.getType() != Material.GRAY_GLAZED_TERRACOTTA) return;
        if (!item.hasItemMeta()) return;
        if(!item.equals(FarmerBlock.getBoyFarmer(amount))) return;

        Block block = event.getBlock();

        block.setType(Material.OBSIDIAN);
        for(int y = block.getY(); y > 0; y--) {

            Location location1 = new Location(player.getLocation().getWorld(), block.getX(), y, block.getZ());
            Block block1 = location1.getBlock();

            if(block1.getType().equals(Material.AIR) || block1.getType().equals(Material.GRAY_GLAZED_TERRACOTTA) || block1.getType().equals(Material.OBSIDIAN)) {
                block1.setType(Material.OBSIDIAN);
            } else {
                player.sendMessage(TextUtils.Wrong("&5&lBOYFARMER &7zakonczyl pracę, ponieważ napotkał &cproblem"));
                y = 0;
            }
        }

        player.getInventory().removeItem(FarmerBlock.getBoyFarmer(1));
    }

    @EventHandler
    public void PlaceKopaczFosy(BlockPlaceEvent event) {
        Player player = event.getPlayer();

        if (event.isCancelled()) return;

        ItemStack item = player.getInventory().getItemInMainHand();
        int amount = item.getAmount();

        if (item.getType() != Material.WHITE_GLAZED_TERRACOTTA) return;
        if (!item.hasItemMeta()) return;
        if(!item.equals(FarmerBlock.getKopaczFosy(amount))) return;

        int amount2 = player.getInventory().getItemInOffHand().getAmount();

        if(player.getInventory().getItemInOffHand() == FarmerBlock.getKopaczFosy(amount2)) {
            player.sendMessage(TextUtils.corolize("&7Wyciagnij ten item z 2 reki"));
            event.setCancelled(true);
            return;
        }

        Block block = event.getBlock();

        block.setType(Material.AIR);
        for(int y = block.getY(); y > 0; y--) {

            Location location1 = new Location(player.getLocation().getWorld(), block.getX(), y, block.getZ());
            Block block1 = location1.getBlock();

            block1.setType(Material.AIR);
        }

        player.getInventory().removeItem(FarmerBlock.getKopaczFosy(1));
    }
}
