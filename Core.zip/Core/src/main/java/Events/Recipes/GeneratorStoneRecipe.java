package Events.Recipes;

import Inventories.AdminPanelGui;
import Inventories.Recipes.BoyFarmersRecipes;
import Inventories.Recipes.Craftings;
import Inventories.Recipes.GSrecipe;
import Inventories.StartEditionGui;
import Utils.FarmerBlock;
import Utils.GeneratorStoneBlock;
import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.w3c.dom.Text;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class GeneratorStoneRecipe implements Listener {

    Main plugin;

    public GeneratorStoneRecipe(Main main) {
        plugin = main;
    }

    List<ItemStack> sandFarmer = Arrays.asList(new ItemStack(Material.GOLD_INGOT, 2)
            , new ItemStack(Material.REDSTONE, 2),
            new ItemStack(Material.SAND, 4),
            new ItemStack(Material.LAVA_BUCKET,1));
    List<ItemStack> boyFarmer = Arrays.asList(new ItemStack(Material.DIAMOND, 2)
            , new ItemStack(Material.REDSTONE, 2),
            new ItemStack(Material.OBSIDIAN, 4),
            new ItemStack(Material.LAVA_BUCKET,1));
    List<ItemStack> DiggerFossa = Arrays.asList(new ItemStack(Material.STONE, 4)
            , new ItemStack(Material.EMERALD, 4),
            new ItemStack(Material.DIAMOND_PICKAXE, 1));


    @EventHandler
    public void OnClickGeneratorStoneGui(InventoryClickEvent event) {
        if (event.getClickedInventory() == null) return;


        Player player = (Player) event.getWhoClicked();
        Inventory inv = player.getInventory();

        if (event.getClickedInventory() == player.getInventory()) return;


        if(event.getClickedInventory().equals(GSrecipe.GeneratorStoneRecipe)) {

            if(event.getRawSlot() == 49) {
                player.openInventory(Craftings.OpenCraftings(player));
            }

            if(event.getRawSlot() == 34) {
                if(inv.contains(Material.STONE, 9)) {
                    player.getInventory().addItem(GeneratorStoneBlock.getGeneratorStoneBlock(1));
                    player.getInventory().removeItem(new ItemStack(Material.STONE, 9));
                    player.sendMessage(TextUtils.corolize("&a&lSukces! &7Wytworzyles Stoniarke"));
                } else {
                    player.sendMessage(TextUtils.Wrong("&7Nie masz wszystkich itemów do stworzenia tej &freceptury"));
                }
            }

            event.setCancelled(true);
        }
        if(event.getClickedInventory().equals(BoyFarmersRecipes.BoyFarmer)) {
            if(event.getRawSlot() == 49) {
                player.openInventory(Craftings.OpenCraftings(player));
            }

            if(event.getRawSlot() == 34) {

                if(inv.contains(Material.OBSIDIAN, 4) && inv.contains(Material.REDSTONE, 2) && inv.contains(Material.DIAMOND, 2) && inv.contains(Material.LAVA_BUCKET, 1)) {
                    player.getInventory().addItem(FarmerBlock.getBoyFarmer(1));

                    for (ItemStack itemStack : boyFarmer) {
                        inv.remove(itemStack);
                    }

                    player.sendMessage(TextUtils.corolize("&a&lSukces! &7Wytworzyles BoyFarmera"));
                } else {
                    player.sendMessage(TextUtils.Wrong("&7Nie masz wszystkich itemów do stworzenia tej &freceptury"));
                }
            }
            event.setCancelled(true);
        }
        if(event.getClickedInventory().equals(BoyFarmersRecipes.SandFarmer)) {
            if(event.getRawSlot() == 49) {
                player.openInventory(Craftings.OpenCraftings(player));
            }

            if(event.getRawSlot() == 34) {
                if(inv.contains(Material.SAND, 4) && inv.contains(Material.REDSTONE, 2) && inv.contains(Material.GOLD_INGOT, 2) && inv.contains(Material.LAVA_BUCKET, 1)) {
                    player.getInventory().addItem(FarmerBlock.getSandFarmer(1));

                    for (ItemStack itemStack : sandFarmer) {
                        inv.remove(itemStack);
                    }

                    player.sendMessage(TextUtils.corolize("&a&lSukces! &7Wytworzyles SandFarmer"));
                } else {
                    player.sendMessage(TextUtils.Wrong("&7Nie masz wszystkich itemów do stworzenia tej &freceptury"));
                }
            }
            event.setCancelled(true);
        }
        if(event.getClickedInventory().equals(BoyFarmersRecipes.DiggerFossa)) {
                if(event.getRawSlot() == 49) {
                    player.openInventory(Craftings.OpenCraftings(player));
                }


                if(event.getRawSlot() == 34) {
                    if(inv.contains(Material.STONE, 4) && inv.contains(Material.EMERALD, 4) && inv.contains(Material.DIAMOND_PICKAXE, 1)) {
                        player.getInventory().addItem(FarmerBlock.getSandFarmer(1));

                        for (ItemStack itemStack : DiggerFossa) {
                            inv.remove(itemStack);
                        }

                        player.sendMessage(TextUtils.corolize("&a&lSukces! &7Wytworzyles SandFarmer"));
                    } else {
                        player.sendMessage(TextUtils.Wrong("&7Nie masz wszystkich itemów do stworzenia tej &freceptury"));
                    }
                }
            event.setCancelled(true);
            }
        }
    }

