package Events;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatManage implements Listener {

    Main plugin;

    boolean ifChatIsOn = Main.getMain().getConfig().getBoolean("ChatStatus");

    public ChatManage(Main main) {
        plugin = main;
    }

    @EventHandler
    public void ChatManager(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();

        if(!ifChatIsOn) return;

        if(!player.isOp() || !player.hasPermission("dizzycore.text.write")) return;

        event.setCancelled(true);
        player.sendMessage(TextUtils.corolize("&c&l✘ &7Chat jest &c&lWYŁĄCZONY!"));
    }

}
