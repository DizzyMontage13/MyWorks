package Timers;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.*;

public class CleanItems implements Runnable{


    public static int timeout = Main.getMain().getConfig().getInt("ClearItemsInSecond");

    public void run() {
        timeout--;

        if(timeout == 20) {
            TextUtils.broadcast("&7&l[ &2&lOTCHLAN &7&l] &fItemy zostaną usunięte za &e10 &fsekund");
        }

        if(timeout == 10) {
            TextUtils.broadcast("&7&l[ &2&lOTCHLAN &7&l] &fItemy zostaną usunięte za &e5 &fsekund");
        }

        if(timeout == 6) {
            TextUtils.broadcast("&7&l[ &2&lOTCHLAN &7&l] &fItemy zostaną usunięte za &e3 &fsekundy");
        }

        if (timeout == 4) {
            TextUtils.broadcast("&7&l[ &2&lOTCHLAN &7&l] &fItemy zostaną usunięte za &22 &fsekundy");
        }

        if(timeout == 2) {
            TextUtils.broadcast("&7&l[ &2&lOTCHLAN &7&l] &fItemy zostaną usunięte za &31 &fsekunde");
        }

        if(timeout == 0) {
            TextUtils.broadcast("&7&l[ &2&lOTCHLAN &7&l] &fItemy zostały &c&lUSUNIĘTE!");

            for (World world : Bukkit.getWorlds()) {
                for (Entity entity : world.getEntities()) {
                    if (entity.getType().equals(EntityType.DROPPED_ITEM)) {
                        entity.remove();
                    }
                }
            }

            timeout = Main.getMain().getConfig().getInt("ClearItemsInSecond");
        }

    }
}
