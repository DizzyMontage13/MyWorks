package Timers;

import Utils.TextUtils;
import com.Challangerson.Main;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;

public class AutoMessage {

    static Main plugin;

    public AutoMessage(Main main) {
        plugin = main;
    }



    public static void start() {
        new BukkitRunnable() {

            int c = 0;
            final List<String> messages = plugin.getConfig().getStringList("messages");

            @Override
            public void run() {
                if(c < messages.size()) {
                    for (Player players : Bukkit.getOnlinePlayers()) {
                        players.sendMessage(TextUtils.colorizeWithPrefix(" " + messages.get(c)));
                    }
                    c++;
                } else {
                    c = 0;
                }
            }
        }.runTaskTimer(plugin, 20L * plugin.getConfig().getInt("time"), 20L * plugin.getConfig().getInt("time"));
    }

}
