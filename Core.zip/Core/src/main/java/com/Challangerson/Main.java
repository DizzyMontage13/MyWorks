package com.Challangerson;

import Components.*;
import Components.Recipes.FarmersRecipe;
import Components.Recipes.GeneratorStoneBlockRecipe;
import Events.*;
import Events.ClickInGui.*;
import Events.Drop;
import Events.Recipes.FarmerPlace;
import Events.Recipes.GeneratorStoneRecipe;
import PacketListeners.Motd;
import PacketListeners.ProtocalLibImplementation;
import Timers.AutoMessage;
import Timers.CleanItems;
import Utils.mySQL;
import commands.admin.*;
import commands.player.*;
import org.bukkit.Bukkit;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;

import java.lang.reflect.Proxy;
import java.util.Objects;


public class Main extends JavaPlugin {


    public static Main Main;

    private Proxy proxy;

    private Utils.mySQL mySQL;

    private UserManager userManager;


    public UserManager getUserManager() {
        return this.userManager;
    }

    public mySQL getMySQL() {
        return this.mySQL;
    }


    @Override
    public void onEnable() {
        Main = this;

        //SPRAWDZIC DROP

        this.proxy = proxy;


        this.userManager = new UserManager();

        this.mySQL = new mySQL();
        this.mySQL.connect();
        this.mySQL.loadUsers();

        RandomDropData.CreateDrops();
        CaseDropData.CreateDropCases();

        if(!getDataFolder().exists()) {
            getDataFolder().mkdirs();
        }
        saveDefaultConfig();



        new AutoMessage(this);
        new GeneratorStoneBlockRecipe(this);
        new FarmersRecipe(this);


        DropFile.saveDefaultConfig();
        CaseFile.saveDefaultConfig();

        AutoMessage.start();


        Objects.requireNonNull(getCommand("pomoc")).setExecutor(new HelpCommand());
        Objects.requireNonNull(getCommand("vip")).setExecutor(new VipCommand());
        Objects.requireNonNull(getCommand("svip")).setExecutor(new SVipCommand());
        Objects.requireNonNull(getCommand("drop")).setExecutor(new DropCommand());
        Objects.requireNonNull(getCommand("case")).setExecutor(new PremiumCaseCommand());
        Objects.requireNonNull(getCommand("gamemode")).setExecutor(new GamemodeCommand());
        Objects.requireNonNull(getCommand("fly")).setExecutor(new FlyCommand());
        Objects.requireNonNull(getCommand("heal")).setExecutor(new HealCommand());
        Objects.requireNonNull(getCommand("kick")).setExecutor(new KickCommand());
        Objects.requireNonNull(getCommand("tp")).setExecutor(new TpCommand());
        Objects.requireNonNull(getCommand("teleport")).setExecutor(new TpCommand());
        Objects.requireNonNull(getCommand("tpa")).setExecutor(new TpaCommand());
        Objects.requireNonNull(getCommand("tpaccept")).setExecutor(new TpacceptCommand());
        Objects.requireNonNull(getCommand("tpadeny")).setExecutor(new TpaDeny());
        Objects.requireNonNull(getCommand("setspawn")).setExecutor(new SetSpawnCommand(this));
        Objects.requireNonNull(getCommand("spawn")).setExecutor(new SpawnCommand(this));
        Objects.requireNonNull(getCommand("msg")).setExecutor(new MsgCommand());
        Objects.requireNonNull(getCommand("r")).setExecutor(new rCommand());
        Objects.requireNonNull(getCommand("kit")).setExecutor(new KitCommand());
        Objects.requireNonNull(getCommand("przeladuj")).setExecutor(new RestartPluginCommand(this));
        Objects.requireNonNull(getCommand("speed")).setExecutor(new SpeedCommand());
        Objects.requireNonNull(getCommand("adminpanel")).setExecutor(new AdminPanelCommand());
        Objects.requireNonNull(getCommand("vanish")).setExecutor(new VanishCommand());
        Objects.requireNonNull(getCommand("invsee")).setExecutor(new InvSeeCommand());
        Objects.requireNonNull(getCommand("sethome")).setExecutor(new SetHomeCommand());
        getCommand("craftingi").setExecutor(new CraftingiCommand());


        ProtocalLibImplementation pli = new ProtocalLibImplementation(this);
        pli.setupIntegration();

        PluginManager pm = Bukkit.getPluginManager();

        pm.registerEvents(new UnknowCommand(this), this);
        pm.registerEvents(new DropClickEvent(this), this);
        pm.registerEvents(new ChestPlace(this), this);
        pm.registerEvents(new MoveOnTeleport(this), this);
        pm.registerEvents(new ChatUtilsInChat(this), this);
        pm.registerEvents(new BlockCommands(this), this);
        pm.registerEvents(new KitClickEvent(this), this);
        pm.registerEvents(new CheckKitsGui(this), this);
        pm.registerEvents(new GenerateStone(this), this);
        pm.registerEvents(new BlockDiamondArmor(this), this);
        pm.registerEvents(new AdminPanelClickEvent(this), this);
        pm.registerEvents(new EnchantDisable(this), this);
        pm.registerEvents(new Drop(this), this);
        pm.registerEvents(new GeneratorStoneRecipe(this), this);
        pm.registerEvents(new FarmerPlace(this), this);
        pm.registerEvents(new CraftingsGui(this), this);
        pm.registerEvents(new Motd(this), this);
        pm.registerEvents(new MoveOnCommand(this), this);
        pm.registerEvents(new StoneDropGuiClick(this), this);

        GeneratorStoneBlockRecipe.getRecipe();
        FarmersRecipe.getBoyFarmerRecipe();
        FarmersRecipe.getSandFarmerRecipe();
        FarmersRecipe.getKopaczFosy();

        BukkitScheduler bukkitScheduler = Bukkit.getScheduler();
        bukkitScheduler.runTaskTimer(this, new CleanItems(), 0L, 20L);

    }


    @Override
    public void onDisable() {
        this.mySQL.shutdown();
    }



    public static Main getMain() {
        return Main;
    }
}
